from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QTreeWidget, QTreeWidgetItem,
    QLineEdit, QPushButton, QHBoxLayout, QInputDialog, QMessageBox, QMenu
)
from PyQt6.QtCore import Qt
from browser.bookmarks.bookmark_manager import BookmarkManager, BookmarkItem

class BookmarksDialog(QDialog):
    """
    Janela completa para gerenciar (adicionar, remover, mover) favoritos e pastas.
    Exibe a árvore de BookmarkItem do BookmarkManager.
    """
    def __init__(self, manager: BookmarkManager, parent=None):
        super().__init__(parent)
        self.manager = manager
        
        self.setWindowTitle("Gerenciador de Favoritos - Redux Browser")
        self.setMinimumSize(600, 450)
        self.setStyleSheet("QDialog { background: #2b2b2b; color: white; }")
        
        self.layout = QVBoxLayout(self)
        
        # Árvore
        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(["Nome", "URL"])
        self.tree.setColumnWidth(0, 250)
        self.tree.setStyleSheet("QTreeWidget { background: #333; color: white; border: none; } "
                                "QTreeWidget::item:hover { background: #444; }")
        self.layout.addWidget(self.tree)
        
        # Botões
        btn_layout = QHBoxLayout()
        
        self.btn_new_bkm = QPushButton("⭐ Novo Favorito")
        self.btn_new_bkm.setStyleSheet("background: #0078d7; color: white; padding: 5px;")
        self.btn_new_bkm.clicked.connect(self._add_bookmark)
        btn_layout.addWidget(self.btn_new_bkm)
        
        self.btn_new_folder = QPushButton("📁 Nova Pasta")
        self.btn_new_folder.setStyleSheet("background: #d28c22; color: white; padding: 5px;")
        self.btn_new_folder.clicked.connect(self._add_folder)
        btn_layout.addWidget(self.btn_new_folder)
        
        self.btn_remove = QPushButton("❌ Remover")
        self.btn_remove.setStyleSheet("background: #e94560; color: white; padding: 5px;")
        self.btn_remove.clicked.connect(self._remove_selected)
        btn_layout.addWidget(self.btn_remove)
        
        self.layout.addLayout(btn_layout)
        
        self.populate()

    def populate(self):
        self.tree.clear()
        root_node = self.manager.get_bookmarks_tree()
        self._build_tree(root_node, self.tree.invisibleRootItem())
        self.tree.expandAll()

    def _build_tree(self, bkm_node: BookmarkItem, tree_item_parent):
        for child in bkm_node.children:
            item = QTreeWidgetItem(tree_item_parent)
            icon = "📁" if child.is_folder() else "🔗"
            item.setText(0, f"{icon} {child.title}")
            item.setText(1, child.url or "")
            item.setData(0, Qt.ItemDataRole.UserRole, child.id) # Guarda o ID invisivel na coluna 0
            
            self._build_tree(child, item)

    def _get_selected_id(self) -> str:
        selected = self.tree.selectedItems()
        if not selected: return "root" # Se nada seleciona, atrela no root
        return selected[0].data(0, Qt.ItemDataRole.UserRole)

    def _add_bookmark(self):
        parent_id = self._get_selected_id()
        title, ok1 = QInputDialog.getText(self, "Novo Favorito", "Nome do Favorito:")
        if ok1 and title:
            url, ok2 = QInputDialog.getText(self, "Novo Favorito", "URL:")
            if ok2 and url:
                if "://" not in url: url = "https://" + url
                self.manager.add_bookmark(title, url, parent_id)
                self.populate()

    def _add_folder(self):
        parent_id = self._get_selected_id()
        title, ok = QInputDialog.getText(self, "Nova Pasta", "Nome da Pasta:")
        if ok and title:
            self.manager.add_folder(title, parent_id)
            self.populate()

    def _remove_selected(self):
        selected = self.tree.selectedItems()
        if not selected: return
        item_id = selected[0].data(0, Qt.ItemDataRole.UserRole)
        
        reply = QMessageBox.question(self, "Remover", "Certeza que deseja remover o item e se for pasta, todo seu conteúdo?",
                                     QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            if self.manager.remove_item(item_id):
                self.populate()
            else:
                QMessageBox.warning(self, "Erro", "Não é possível remover a pasta raíz original.")
