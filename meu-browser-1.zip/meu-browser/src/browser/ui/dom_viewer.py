from PyQt6.QtWidgets import (
    QDockWidget, QTreeWidget, QTreeWidgetItem, 
    QVBoxLayout, QWidget, QTextEdit, QSplitter
)
from PyQt6.QtCore import Qt
from typing import Optional
from browser.engine.html_parser import DOMNode
from browser.engine.render_tree import RenderNode

class DOMViewer(QDockWidget):
    """
    Visualizador da Árvore DOM para o Redux Browser.
    Implementa um painel lateral estilo "DevTools" para inspecionar nós e estilos.
    """
    def __init__(self, parent=None):
        super().__init__("DOM & Estilos (Redux Engine DevTools)", parent)
        self.setAllowedAreas(Qt.DockWidgetArea.RightDockWidgetArea | Qt.DockWidgetArea.LeftDockWidgetArea)
        
        # Container principal no dock
        container = QWidget()
        layout = QVBoxLayout(container)
        
        # Splitter para dividir a view em "Árvore" e "Estilos do Nó Selecionado"
        splitter = QSplitter(Qt.Orientation.Vertical)
        
        # 1. Árvore HMTL
        self.tree_widget = QTreeWidget()
        self.tree_widget.setHeaderLabel("Elementos")
        self.tree_widget.itemClicked.connect(self._on_item_clicked)
        splitter.addWidget(self.tree_widget)
        
        # 2. Visão de Estilos
        self.style_view = QTextEdit()
        self.style_view.setReadOnly(True)
        self.style_view.setPlaceholderText("Selecione um elemento para ver seus estilos computados...")
        splitter.addWidget(self.style_view)
        
        layout.addWidget(splitter)
        self.setWidget(container)
        
        # Mapeamento do item da UI -> Nó Real (pode ser DOMNode ou RenderNode)
        self.node_map = {}

    def populate(self, root_node: Optional[DOMNode], render_root: Optional[RenderNode] = None):
        """Preenche o DevTools recebendo a árvore DOM parseada e, opcionalmente, a RenderTree."""
        self.tree_widget.clear()
        self.node_map.clear()
        self.style_view.clear()
        
        if not root_node:
            return
            
        # Opcional: indexar render_nodes por dom_node_id se quisermos atrelar estilos exatos.
        self.render_map = {}
        if render_root:
            self._build_render_map(render_root)

        root_item = self._create_tree_item(root_node)
        self.tree_widget.addTopLevelItem(root_item)
        root_item.setExpanded(True)

    def _build_render_map(self, r_node: RenderNode):
        self.render_map[id(r_node.dom_node)] = r_node
        for child in r_node.children:
            self._build_render_map(child)

    def _create_tree_item(self, node: DOMNode) -> QTreeWidgetItem:
        """Cria recursivamente os itens do QTreeWidget"""
        item = QTreeWidgetItem()
        
        # Identificação visual na interface
        if node.tag_name == "#text":
            text_preview = node.text_content.replace('\\n', '').strip()
            item.setText(0, f"\"{text_preview[:20]}...\"" if len(text_preview) > 20 else f"\"{text_preview}\"")
        else:
            attrs = " ".join([f'{k}="{v}"' for k, v in node.attributes.items()])
            tag_str = f"<{node.tag_name} {attrs}>" if attrs else f"<{node.tag_name}>"
            item.setText(0, tag_str)
            
        self.node_map[id(item)] = node
        
        # Recursividade para os filhos
        for child in node.children:
            child_item = self._create_tree_item(child)
            item.addChild(child_item)
            
        return item

    def _on_item_clicked(self, item: QTreeWidgetItem, column: int):
        """Quando o usuário clica num nó no DevTools, mostrar os estilos."""
        node = self.node_map.get(id(item))
        if not node:
            return
            
        if node.tag_name == "#text":
            self.style_view.setHtml("<b>Nó de Texto Puro</b><br/>(Herda estilos do pai)")
            return
            
        html = f"<h3>Estilos Computados: &lt;{node.tag_name}&gt;</h3>"
        
        r_node = self.render_map.get(id(node))
        if r_node:
            html += "<table width='100%'>"
            for prop, val in sorted(r_node.styles.items()):
                html += f"<tr><td><b>{prop}</b></td><td style='color:blue;'>{val}</td></tr>"
            html += "</table>"
            
            # Adiciona dimensões Box Model se presente
            if r_node.layout_box:
                lb = r_node.layout_box
                html += f"<hr><b>Box Model (px):</b><br/>"
                html += f"Dimensão: {lb.content.width:.1f}x{lb.content.height:.1f}<br/>"
                html += f"Margem L/T: {lb.margin.x:.1f}/{lb.margin.y:.1f}<br/>"
                html += f"Absolute(x,y): {lb.content.x:.1f}, {lb.content.y:.1f}"
        else:
            html += "<p><i>RenderNode não encontrado (display: none ou erro).</i></p>"
            html += "<b>Atributos HTML Originais:</b><ul>"
            for k, v in node.attributes.items():
                html += f"<li>{k}='{v}'</li>"
            html += "</ul>"
            
        self.style_view.setHtml(html)
