"""
Painel de controle do Fingerprint Randomizer.
Permite ao usuário visualizar e controlar o perfil ativo.
"""
from PyQt6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, 
                             QLabel, QPushButton, QTextEdit, QComboBox,
                             QGroupBox, QProgressBar, QMessageBox, QFormLayout)
from PyQt6.QtCore import Qt
import json

from browser.security.fingerprint_randomizer import RandomizationLevel

class FingerprintPanel(QDialog):
    def __init__(self, randomizer, current_tab_id, parent=None):
        super().__init__(parent)
        self.randomizer = randomizer
        self.current_tab_id = current_tab_id
        
        self.setWindowTitle("🛡️ Redux Browser - Controle de Fingerprint")
        self.resize(500, 600)
        self.setup_ui()
        self.refresh_profile()

    def setup_ui(self):
        layout = QVBoxLayout(self)

        # Top Control
        # control_group = QGroupBox("Nível de Proteção") # Original line
        # control_layout = QHBoxLayout(control_group) # Original line
        # layout.addWidget(header) # This line was in the instruction but 'header' is undefined. Omitting.

        # Level Selector
        level_group = QGroupBox("Nível de Randomização")
        level_layout = QVBoxLayout(level_group) # Pass level_group to the layout constructor

        self.level_combo = QComboBox()
        self.level_combo.addItems([
            "OFF (Real Data)",
            "LIGHT (Apenas UA)",
            "MEDIUM (UA, Resolução, TZ)",
            "AGGRESSIVE (Gera todos os ruídos)",
            "PER_TAB (Aba tem próprio)",
            "PER_SESSION (Fixa até reiniciar)"
        ])
        self.level_combo.addItems([l.value for l in RandomizationLevel])
        self.level_combo.setCurrentText(self.randomizer.level.value)
        self.level_combo.currentTextChanged.connect(self._change_level)
        level_layout.addWidget(self.level_combo)
        
        # Protective Status (Score + Badges)
        self.status_label = QLabel()
        self.status_label.setStyleSheet("font-weight: bold;")
        self.status_bar = QProgressBar()
        self.status_bar.setRange(0, 100)
        self.status_bar.setTextVisible(True)
        level_layout.addWidget(QLabel("Score de Proteção:"))
        level_layout.addWidget(self.status_bar)
        level_layout.addWidget(self.status_label)
        
        level_group.setLayout(level_layout)
        layout.addWidget(level_group)

        # Dados Atuais
        self.profile_group = QGroupBox("Perfil Identificado pela Web")
        form_layout = QFormLayout(self.profile_group)
        
        self.lbl_ua = QLabel()
        self.lbl_ua.setWordWrap(True)
        self.lbl_os = QLabel()
        self.lbl_res = QLabel()
        self.lbl_tz = QLabel()
        self.lbl_webgl = QLabel()
        
        form_layout.addRow("User-Agent:", self.lbl_ua)
        form_layout.addRow("OS / Plataforma:", self.lbl_os)
        form_layout.addRow("Resolução:", self.lbl_res)
        form_layout.addRow("Timezone / Lang:", self.lbl_tz)
        form_layout.addRow("WebGL Renderer:", self.lbl_webgl)

        self.json_view = QTextEdit()
        self.json_view.setReadOnly(True)
        self.json_view.setMaximumHeight(150)
        form_layout.addRow("Data Payload:", self.json_view)
        
        layout.addWidget(self.profile_group)

        # Botões
        btn_layout = QHBoxLayout()
        self.btn_regenerate = QPushButton("🔄 Gerar Novo Perfil")
        self.btn_regenerate.clicked.connect(self.on_regenerate)
        
        self.btn_copy = QPushButton("📋 Copiar Perfil")
        self.btn_copy.clicked.connect(self.on_copy)
        
        btn_layout.addWidget(self.btn_regenerate)
        btn_layout.addWidget(self.btn_copy)
        
        # Test Quick Button
        test_btn = QPushButton("🧪 Teste Rápido (EFF)")
        test_btn.setStyleSheet("background-color: #2e7d32; color: white; font-weight: bold;")
        test_btn.clicked.connect(self._run_eff_test)
        btn_layout.addWidget(test_btn)
        
        layout.addLayout(btn_layout)

    def _change_level(self, text):
        try:
            new_level = RandomizationLevel(text)
            self.randomizer.set_level(new_level)
            self.refresh_profile()
        except ValueError:
            QMessageBox.warning(self, "Erro", f"Nível de randomização inválido: {text}")

    def on_regenerate(self):
        self.randomizer.regenerate_profile(self.current_tab_id)
        self.refresh_profile()
        QMessageBox.information(self, "Fingerprint", "Perfil da aba ativo recriado com sucesso.\nRecarregue a página para aplicar!")

    def on_copy(self):
        from PyQt6.QtWidgets import QApplication
        QApplication.clipboard().setText(self.json_view.toPlainText())

    def _run_eff_test(self):
        """Abre a guia da EFF no tab ativo."""
        if hasattr(self.parent, "tab_widget"):
            tab = self.parent.tab_widget.get_current_tab()
            if tab:
                tab.load_url("https://coveryourtracks.eff.org/")
        self.close()

    def refresh_profile(self):
        prof = self.randomizer.get_profile(self.current_tab_id)
        
        if not prof:
            self.lbl_ua.setText("N/A")
            self.lbl_os.setText("N/A")
            self.lbl_res.setText("N/A")
            self.lbl_tz.setText("N/A")
            self.lbl_webgl.setText("N/A")
            self.json_view.setText("{}")
            self._update_score_ui(0, "🔴 Desprotegido (Real)")
            return
            
        lvl = self.randomizer.level
        if lvl == RandomizationLevel.OFF:
            self._update_score_ui(0, "🔴 Desprotegido (Real)")
        elif lvl == RandomizationLevel.LIGHT:
            self._update_score_ui(30, "🟠 Leve (UA alterado, Rastreadores identificam)")
        elif lvl == RandomizationLevel.MEDIUM:
            self._update_score_ui(60, "🟡 Médio (Resolução e timezone spoofados)")
        elif lvl == RandomizationLevel.AGGRESSIVE:
            self._update_score_ui(85, "🟢 Canvas/Audio Spoofed (Alto risco de quebra)")
        elif lvl == RandomizationLevel.PER_TAB or lvl == RandomizationLevel.PER_SESSION: # Assuming these can also be aggressive or stealth
            # For PER_TAB/PER_SESSION, the actual level of randomization depends on internal settings.
            # For simplicity, let's assume they provide a good level of protection if active.
            # A more robust implementation would check the actual randomization parameters.
            self._update_score_ui(85, "🟢 Canvas/Audio Spoofed (Alto risco de quebra)")
        # The instruction had a "stealth" level, which is not in the original enum.
        # If RandomizationLevel.STEALTH existed, it would be handled here.
        # elif lvl.value == "stealth":
        #     self._update_score_ui(100, "🟢 Canvas/Audio/WebGL + Dist. ESTATÍSTICA + WebRTC OFF")
        
        self.lbl_ua.setText(prof.user_agent)
        self.lbl_os.setText(f"{prof.os_name} {prof.os_version} ({prof.platform})")
        self.lbl_res.setText(f"{prof.screen_width}x{prof.screen_height} px @ {int(prof.pixel_ratio)}x")
        self.lbl_tz.setText(f"{prof.timezone} (offset {prof.timezone_offset}) | {prof.language}")
        self.lbl_webgl.setText(prof.webgl_renderer)
        
        self.json_view.setText(json.dumps(prof.to_dict(), indent=2))

    def _update_score_ui(self, score: int, details: str):
        self.status_bar.setValue(score)
        
        if score >= 85: p_color = "#388E3C"
        elif score >= 50: p_color = "#FBC02D"
        else: p_color = "#D32F2F"
        
        self.status_bar.setStyleSheet(f"""
            QProgressBar {{ border: 1px solid grey; border-radius: 5px; text-align: center; }}
            QProgressBar::chunk {{ background-color: {p_color}; width: 10px; }}
        """)
        
        html_status = f"<br/><b>Resumo:</b> {details}<br/><br/>"
        if score > 0:
            html_status += "🟢 Headers: Spoofados (UA + Sec-CH-UA)<br/>"
        if score >= 60:
            html_status += "🟢 Timezone/Tela: Protegido<br/>"
        if score >= 85:
            html_status += "🟢 Canvas: Protegido (ruído ativo)<br/>"
            html_status += "🟢 WebGL: Spoofado (vendor/renderer falsos)<br/>"
            html_status += "🟢 Audio: Protegido (ruído ativo)<br/>"
            html_status += "🟢 Fontes: Limitadas<br/>"
        if score == 100:
            html_status += "🟢 WebRTC: Bloqueado (sem IP leak)<br/>"
            html_status += "🟢 Ocultação: Comportamento Comum<br/>"
            
        self.status_label.setText(html_status)
