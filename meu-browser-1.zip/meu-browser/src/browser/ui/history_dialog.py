from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QListWidget, QListWidgetItem,
    QLineEdit, QPushButton, QHBoxLayout
)
from browser.history.history_manager import HistoryManager

class HistoryDialog(QDialog):
    """
    Interface para visualização e busca do Histórico Global.
    Mostra as entradas armazenadas no JSON do HistoryManager.
    """
    def __init__(self, history_manager: HistoryManager, parent=None):
        super().__init__(parent)
        self.history_manager = history_manager
        
        self.setWindowTitle("Histórico de Navegação - Redux Browser")
        self.setMinimumSize(500, 400)
        self.setStyleSheet("QDialog { background: #2b2b2b; color: white; }")
        
        self.layout = QVBoxLayout(self)
        
        # Pesquisa
        self.search_bar = QLineEdit()
        self.search_bar.setPlaceholderText("Pesquisar no histórico...")
        self.search_bar.setStyleSheet("QLineEdit { background: #444; color: white; border: none; padding: 5px; border-radius: 5px; }")
        self.search_bar.textChanged.connect(self._filter_history)
        self.layout.addWidget(self.search_bar)
        
        # Lista
        self.list_widget = QListWidget()
        self.list_widget.setStyleSheet("QListWidget { background: #333; color: white; border: none; } QListWidget::item:hover { background: #444; }")
        self.layout.addWidget(self.list_widget)
        
        # Botões da base
        btn_layout = QHBoxLayout()
        self.clear_btn = QPushButton("🗑️ Limpar Histórico")
        self.clear_btn.setStyleSheet("background: #e94560; color: white; padding: 8px; border: none; font-weight: bold;")
        self.clear_btn.clicked.connect(self._clear_all)
        btn_layout.addWidget(self.clear_btn)
        
        self.layout.addLayout(btn_layout)
        
        self.populate()
        
    def populate(self, filter_text: str = ""):
        self.list_widget.clear()
        filter_text = filter_text.lower()
        
        # A list deve vir descrescente e apenas ser exibida
        for entry in self.history_manager.get_history():
            if filter_text in entry.title.lower() or filter_text in entry.url.lower():
                # Formata a data bonitinha
                try: 
                    from datetime import datetime
                    dt = datetime.fromisoformat(entry.timestamp)
                    date_str = dt.strftime("%d/%m %H:%M")
                except: date_str = entry.timestamp

                item = QListWidgetItem(f"[{date_str}] {entry.title} - {entry.url}")
                # Salvamos a URL crua no user data para carregar a aba ao clicar
                item.setData(100, entry.url)
                self.list_widget.addItem(item)
                
    def _filter_history(self, text: str):
        self.populate(text)
        
    def _clear_all(self):
        from PyQt6.QtWidgets import QMessageBox
        resposta = QMessageBox.question(self, "Atenção", "Deseja apagar todo o histórico definitivamente?", QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if resposta == QMessageBox.StandardButton.Yes:
            self.history_manager.clear_history()
            self.populate()
