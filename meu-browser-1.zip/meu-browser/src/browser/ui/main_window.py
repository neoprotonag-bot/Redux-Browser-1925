from PyQt6.QtCore import QUrl, Qt
from PyQt6.QtWidgets import (
    QMainWindow, QToolBar, QLineEdit, QStatusBar, 
    QVBoxLayout, QWidget, QComboBox, QMessageBox, QMenu, QHBoxLayout
)
from PyQt6.QtGui import QPainter, QColor, QFont, QPen, QBrush, QIcon, QAction
from typing import Optional

from browser.engine.html_parser import HTMLParser, DOMTree
from browser.engine.css_parser import CSSParser
from browser.engine.render_tree import RenderTree, RenderNode
from browser.engine.layout import LayoutEngine
from browser.ui.dom_viewer import DOMViewer

from browser.ui.tab_widget import TabWidget
from browser.history.history_manager import HistoryManager
from browser.bookmarks.bookmark_manager import BookmarkManager
from browser.ui.bookmarks_bar import BookmarksBar
from browser.ui.history_dialog import HistoryDialog
from browser.ui.bookmarks_dialog import BookmarksDialog
from browser.cache.cache_manager import CacheManager

from browser.security.fingerprint_randomizer import FingerprintRandomizer, RandomizationLevel
from browser.security.fingerprint_injector import FingerprintInjector
from browser.ui.fingerprint_panel import FingerprintPanel

class ReduxRenderWidget(QWidget):
    """
    Widget customizado que desenha a RenderTree usando QPainter.
    Esta é a ponta final da nossa pipeline educacional: DOM -> CSSOM -> Layout -> Paint
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        self.render_tree_root: Optional[RenderNode] = None
        # Fundo branco por padrão
        self.setStyleSheet("background-color: white;")

    def set_render_tree(self, root: Optional[RenderNode]):
        self.render_tree_root = root
        self.update() # Força o repaint

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        
        if not self.render_tree_root:
            return
            
        self._paint_node(painter, self.render_tree_root)

    def _paint_node(self, painter: QPainter, node: RenderNode):
        """Desenha a LayoutBox e o Texto na tela recursivamente"""
        if not node.layout_box:
            return
            
        box = node.layout_box
        x = int(box.content.x)
        y = int(box.content.y)
        w = int(box.content.width)
        h = int(box.content.height)

        # Trata nós de texto separadamente
        if node.dom_node.tag_name == "#text":
            text = node.dom_node.text_content.strip()
            if text:
                color = QColor(node.styles.get('color', 'black'))
                painter.setPen(color)
                
                # fonte
                font_size_str = node.styles.get('font-size', '16px').replace('px', '').replace('em', '')
                try: 
                    font_size = int(float(font_size_str)) 
                    if 'em' in node.styles.get('font-size', '16px'): font_size *= 16
                except: font_size = 16
                
                font = QFont(node.styles.get('font-family', 'sans-serif'), font_size)
                if node.styles.get('font-weight') == 'bold': font.setBold(True)
                if node.styles.get('font-style') == 'italic': font.setItalic(True)
                
                painter.setFont(font)
                # desenha o texto alinhado com o box
                painter.drawText(x, y + font_size, text) 
        else:
            # Pinta o background
            bg_color = node.styles.get('background-color', 'transparent')
            if bg_color != 'transparent':
                painter.fillRect(x, y, w, h, QColor(bg_color))
                
            # TODO: bordas (simplificado para educacional)
            
        # Pinta filhos
        for child in node.children:
            self._paint_node(painter, child)


class MainWindow(QMainWindow):
    """
    Janela Principal do Redux Browser (Fase 3 com Abas).
    Gerencia a UI, toggle entre QtWebEngine vs Redux Engine, DevTools e Managers Ativos
    """
    def __init__(self, is_private=False, history_mgr=None, bookmark_mgr=None, cache_mgr=None):
        super().__init__()
        self.is_private = is_private
        
        # Compartilha as instancias entre janelas abertas
        self.history_manager = history_mgr or HistoryManager()
        self.bookmark_manager = bookmark_mgr or BookmarkManager()
        self.cache_manager = cache_mgr or CacheManager()
        
        # Security: Fingerprint
        self.fingerprint_randomizer = FingerprintRandomizer()
        if self.is_private:
            self.fingerprint_randomizer.set_level(RandomizationLevel.AGGRESSIVE)
        self.fingerprint_injector = FingerprintInjector(self.fingerprint_randomizer)
        
        # Define título baseado no modo
        private_str = " (Privado 🔒)" if self.is_private else ""
        self.setWindowTitle(f"Redux Browser{private_str}")
        self.setMinimumSize(1024, 768)
        
        # Cria as páginas offline default base
        self._init_pages()
        
        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)
        self.layout = QVBoxLayout(self.central_widget)
        self.layout.setContentsMargins(0, 0, 0, 0)
        # Estado do motor atual (0: WebEngine, 1: ReduxEngine)
        self.active_engine = 0
        
        self.setup_ui()
        
    def _init_pages(self):
        """Inicializa as strings de about:home e about:error com identidade Redux"""
        self.home_html = """
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body {
                    margin: 0; padding: 0;
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #1a1a2e, stop:1 #16213e);
                    color: white; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                    height: 100vh; display: flex; flex-direction: column;
                    align-items: center; justify-content: center;
                }
                .logo { font-size: 3em; font-weight: bold; margin-bottom: 5px; color: #e94560; }
                .subtitle { font-size: 1.2em; color: #a2a2bd; margin-bottom: 40px; }
                .search-box {
                    width: 60%; max-width: 600px; padding: 15px 20px;
                    border-radius: 30px; border: none; font-size: 1.1em;
                    background: rgba(255, 255, 255, 0.1); color: white;
                    outline: none; text-align: center;
                }
                .speed-dial { margin-top: 50px; display: flex; gap: 20px; }
                .dial-btn {
                    padding: 15px 30px; background: rgba(233, 69, 96, 0.2);
                    border-radius: 10px; text-decoration: none; color: white;
                    font-weight: bold; transition: background 0.3s;
                }
                .dial-btn:hover { background: rgba(233, 69, 96, 0.5); }
            </style>
        </head>
        <body style="background-color: #1a1a2e; color: white; text-align: center; padding-top: 150px;">
            <div class="logo">REDUX</div>
            <div class="subtitle">Redux Browser v0.1 &mdash; Seu navegador, suas regras.</div>
            
            <input class="search-box" type="text" placeholder="Pesquisar na web ou digitar URL..." />
            
            <div class="speed-dial" style="margin-top: 40px;">
                <a href="https://github.com" class="dial-btn" style="margin: 10px; padding: 10px; background-color: #e94560; color: white;">GitHub</a>
                <a href="https://stackoverflow.com" class="dial-btn" style="margin: 10px; padding: 10px; background-color: #e94560; color: white;">StackOverflow</a>
                <a href="https://wikipedia.org" class="dial-btn" style="margin: 10px; padding: 10px; background-color: #e94560; color: white;">Wikipedia</a>
            </div>
        </body>
        </html>
        """
        
        self.error_html = """
        <html>
        <head>
            <style>
                body { background-color: #f8d7da; color: #721c24; font-family: sans-serif; text-align: center; padding-top: 100px; }
                h1 { font-size: 2.5em; }
                p { font-size: 1.2em; }
                .btn { padding: 10px 20px; background-color: #721c24; color: white; text-decoration: none; border-radius: 5px; }
            </style>
        </head>
        <body style="background-color: #f8d7da; color: #721c24; text-align: center; padding: 100px;">
            <h1>Ops! N&atilde;o foi poss&iacute;vel conectar</h1>
            <p>Ocorreu um problema ao tentar carregar esta p&aacute;gina.</p>
            <ul style="list-style: none; padding: 0;">
                <li>Verifique sua conex&atilde;o com a internet.</li>
                <li>Verifique se o endere&ccedil;o foi digitado corretamente.</li>
            </ul>
            <br>
            <a href="about:home" class="btn" style="background-color: #721c24; color: white; padding: 10px; text-decoration: none;">Tentar novamente (Home)</a>
        </body>
        </html>
        """
        
    def setup_ui(self):
        # -- MENU SUPERIOR E TOOLBARS --
        self.toolbar = QToolBar("Navegação")
        self.toolbar.setMovable(False)
        if self.is_private:
            self.toolbar.setStyleSheet("QToolBar { background: #300000; border-bottom: 2px solid #e94560; } QToolButton { color: white; }")
        else:
            self.toolbar.setStyleSheet("QToolBar { background: #222; border-bottom: 1px solid #444; } QToolButton { color: white; }")
        self.addToolBar(self.toolbar)
        
        # Botoes navegacao
        self.back_btn = QAction("⬅️", self)
        self.back_btn.setShortcut("Alt+Left")
        self.back_btn.triggered.connect(self.navigate_back)
        self.toolbar.addAction(self.back_btn)
        
        self.forward_btn = QAction("➡️", self)
        self.forward_btn.setShortcut("Alt+Right")
        self.forward_btn.triggered.connect(self.navigate_forward)
        self.toolbar.addAction(self.forward_btn)
        
        self.reload_btn = QAction("🔄", self)
        self.reload_btn.setShortcut("F5")
        self.reload_btn.triggered.connect(self.reload_page)
        self.toolbar.addAction(self.reload_btn)
        
        self.home_btn = QAction("🏠", self)
        self.home_btn.triggered.connect(self.navigate_home)
        self.toolbar.addAction(self.home_btn)
        
        # Botoes sistema
        self.new_tab_btn = QAction("➕ Nova Aba (Ctrl+T)", self)
        self.new_tab_btn.setShortcut("Ctrl+T")
        self.new_tab_btn.triggered.connect(self.new_tab)
        self.toolbar.addAction(self.new_tab_btn)
        
        # URL BAR
        self.url_bar = QLineEdit()
        self.url_bar.setStyleSheet("QLineEdit { background: #333; color: white; border-radius: 10px; padding: 5px; }")
        self.url_bar.setPlaceholderText("Digite uma URL e pressione Enter...")
        self.url_bar.returnPressed.connect(self.navigate_to_url)
        self.toolbar.addWidget(self.url_bar)
        
        # Global Shortcuts invisiveis toolbar (Focar URL, Fechar Aba)
        self.focus_url_btn = QAction("Focar URL", self)
        self.focus_url_btn.setShortcut("Ctrl+L")
        self.focus_url_btn.triggered.connect(self.url_bar.setFocus)
        self.addAction(self.focus_url_btn)
        
        self.close_tab_btn = QAction("Fechar Aba", self)
        self.close_tab_btn.setShortcut("Ctrl+W")
        self.close_tab_btn.triggered.connect(self.close_current_tab)
        self.addAction(self.close_tab_btn)
        
        # ENGINE TOGGLE (Agora per-tab!)
        self.engine_combo = QComboBox()
        self.engine_combo.setStyleSheet("QComboBox { background: #444; color: white; padding: 3px; border-radius: 5px; }")
        self.engine_combo.addItem("🌐 QtWebEngine (Padrão)")
        self.engine_combo.addItem("🧪 Redux Engine (Experimental)")
        self.engine_combo.currentIndexChanged.connect(self.switch_engine)
        self.toolbar.addWidget(self.engine_combo)
        
        # -- BARRA DE FAVORITOS E MENUS EXTRAS --
        menu_bar = self.menuBar()
        arquivo_menu = menu_bar.addMenu("Arquivo")
        arquivo_menu.addAction("Nova Aba", "Ctrl+T", self.new_tab)
        arquivo_menu.addAction("Nova Janela Privada", "Ctrl+Shift+P", self.open_private_window)
        
        history_menu = menu_bar.addMenu("Histórico")
        history_menu.addAction("Abrir Histórico...", "Ctrl+H", self.show_history)
        
        bookmarks_menu = menu_bar.addMenu("Favoritos")
        bookmarks_menu.addAction("Gerenciador de Favoritos...", "Ctrl+Shift+B", self.show_bookmarks)
        
        cache_menu = menu_bar.addMenu("Manutenção")
        cache_menu.addAction("Limpar Cache Local", "Ctrl+Shift+Del", self.clear_cache)
        
        security_menu = menu_bar.addMenu("Segurança")
        security_menu.addAction("Fingerprint Randomizer...", "Ctrl+Shift+F", self.show_fingerprint_panel)
        
        # Barra Horizontal abaixo
        self.bookmarks_bar = BookmarksBar(self.bookmark_manager)
        self.bookmarks_bar.bookmarkClicked.connect(self._load_network_url)
        self.bookmarks_bar.manageRequested.connect(self.show_bookmarks)
        self.layout.addWidget(self.bookmarks_bar)
        
        # -- TABS (Substitui Renderers diretos) --
        self.tab_widget = TabWidget(self.history_manager, self.fingerprint_injector)
        self.tab_widget.currentTabUrlChanged.connect(self.update_url_bar)
        self.tab_widget.currentTabTitleChanged.connect(self.update_title)
        self.layout.addWidget(self.tab_widget)
        
        # -- DEVTOOLS PANE --
        self.dom_viewer = DOMViewer(self)
        self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, self.dom_viewer)
        self.dom_viewer.hide()
        
        # F12 atalho local 
        self.devtools_btn = QAction("🛠️", self)
        self.devtools_btn.setShortcut("F12")
        self.devtools_btn.triggered.connect(self.toggle_devtools)
        self.toolbar.addAction(self.devtools_btn)
        
        # Barra status
        self.status_bar = QStatusBar()
        self.status_bar.setStyleSheet("background: #222; color: #aaa;")
        self.setStatusBar(self.status_bar)
        
        self.new_tab() # Cria a aba matriz about:home
        
    def new_tab(self):
        self.tab_widget.add_new_tab("about:home", self.is_private)
        self.navigate_home()

    def close_current_tab(self):
        index = self.tab_widget.currentIndex()
        if index != -1:
            self.tab_widget.close_tab(index)
            # Se todas foram fechadas, cria uma home silenciosa
            if self.tab_widget.count() == 0:
                self.new_tab()

    def open_private_window(self):
        self.private_window = MainWindow(is_private=True, history_mgr=self.history_manager, bookmark_mgr=self.bookmark_manager, cache_mgr=self.cache_manager)
        self.private_window.show()

    def show_history(self):
        dlg = HistoryDialog(self.history_manager, self)
        dlg.exec()

    def show_bookmarks(self):
        dlg = BookmarksDialog(self.bookmark_manager, self)
        dlg.exec()
        self.bookmarks_bar.populate() # Atualiza em caso de mudanças

    def clear_cache(self):
        reply = QMessageBox.question(self, "Limpar Cache", "Confirma a limpeza de todo o cache interceptado do disco?")
        if reply == QMessageBox.StandardButton.Yes:
            self.cache_manager.clear_cache()
            self.status_bar.showMessage("Cache apagado com sucesso", 3000)

    def switch_engine(self, index: int):
        tab = self.tab_widget.get_current_tab()
        if tab:
            tab.switch_engine(index)
            tab.reload()

    def toggle_devtools(self):
        if self.dom_viewer.isVisible(): self.dom_viewer.hide()
        else: self.dom_viewer.show()

    def show_fingerprint_panel(self):
        tab = self.tab_widget.get_current_tab()
        tab_id = tab.id if tab else "default"
        dlg = FingerprintPanel(self.fingerprint_randomizer, tab_id, self)
        dlg.exec()

    def navigate_home(self):
        self.url_bar.setText("about:home")
        self.navigate_to_url()
        
    def navigate_to_url(self):
        url_text = self.url_bar.text().strip()
        if not url_text: return
        tab = self.tab_widget.get_current_tab()
        
        if url_text == "about:home":
            tab.load_html(self.home_html, url_text, "Redux Browser")
            return
            
        if url_text == "about:error":
            tab.load_html(self.error_html, url_text, "Erro de Conexão")
            return
            
        if "://" not in url_text:
            url_text = "https://" + url_text
            self.url_bar.setText(url_text)
            
        self._load_network_url(url_text)

    def _load_network_url(self, url: str):
        """Carrega URL na Engine da aba e registra hit de historico"""
        tab = self.tab_widget.get_current_tab()
        if not tab: return
        
        self.url_bar.setText(url)
        # Registra histórico atrelado a tab e marca flag is_private
        self.history_manager.add_entry(tab.id, url, url, self.is_private)
        
        tab.load_url(url)
        
        # Update devtools with latest DOM if in Redux mode? (Fazemos via sinal em versoes complexas)
        # Por enquanto fica acoplado no sinal loadFinished se precisarmos.

    def _render_html(self, html_source: str, url: str, title: str):
        # Migrado o fluxo pesado p dentros das proprias classes de Tab
        # Se Redux render estava rodando nativo na window, agora rodará em Tab
        tab = self.tab_widget.get_current_tab()
        if tab:
             tab.load_html(html_source, url, title)

    def update_url_bar(self, qurl_str):
        self.url_bar.setText(qurl_str)
        self.url_bar.setCursorPosition(0)
        
    def update_title(self, title):
        private_str = " (Privado 🔒)" if self.is_private else ""
        self.setWindowTitle(f"{title} - Redux Browser{private_str}")
            
    def navigate_back(self):
        tab = self.tab_widget.get_current_tab()
        if tab:
            if tab.active_engine == 0:
                tab.back() # Qt cuida
            else:
                url = self.history_manager.go_back(tab.id)
                if url: self._load_network_url(url)
        
    def navigate_forward(self):
        tab = self.tab_widget.get_current_tab()
        if tab:
             if tab.active_engine == 0:
                 tab.forward()
             else:
                 url = self.history_manager.go_forward(tab.id)
                 if url: self._load_network_url(url)
        
    def reload_page(self):
        tab = self.tab_widget.get_current_tab()
        if tab: tab.reload()
