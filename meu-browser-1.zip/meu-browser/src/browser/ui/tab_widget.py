from PyQt6.QtWidgets import QTabWidget, QWidget, QTabBar
from PyQt6.QtCore import pyqtSignal
from browser.ui.tab import Tab

class TabWidget(QTabWidget):
    """
    Gerenciador de Abas.
    Substitui o antigo layout central, orquestrando mós `Tab`.
    """
    
    # Repassa eventos da aba ativa para que a MainWindow atualize (ex: Barra de URL e Título)
    currentTabUrlChanged = pyqtSignal(str)
    currentTabTitleChanged = pyqtSignal(str)

    def __init__(self, history_manager, fingerprint_injector, parent=None):
        super().__init__(parent)
        self.history_manager = history_manager
        self.fingerprint_injector = fingerprint_injector
        self.setTabsClosable(True)
        self.setMovable(True)  # Permite arrastar abas
        self.setDocumentMode(True) # Visualização flat clássica de abas
        
        self.tabCloseRequested.connect(self.close_tab)
        self.currentChanged.connect(self._on_tab_changed)

    def add_new_tab(self, url: str = "about:home", is_private: bool = False) -> Tab:
        """Cria e anexa uma aba nova com propriedades base."""
        tab = Tab(self, self.history_manager, self.fingerprint_injector, is_private=is_private)
        
        # Conexões para atualizar barra quando esta tab emitir eventos
        tab.urlChanged.connect(self._handle_url_change)
        tab.titleChanged.connect(self._handle_title_change)
        
        icon_text = "🔒 " if is_private else ""
        index = self.addTab(tab, f"{icon_text}Carregando...")
        self.setCurrentIndex(index)
        
        # Se for about:home ou link externo, pede via callback pra app carregar
        # Isso porque about:home é parseado na MainWindow no modelo passado
        # Mas para simplificar as strings do offline, disparamos um sinal Custom?
        if url == "about:home" or url == "about:error":
            # Repassar pra mainwindow por evento de navegação ou carregar direto aqui (necessita string)
            pass 
        
        return tab

    def get_current_tab(self) -> Tab | None:
        """Retorna a Tab presentemente ativa."""
        widget = self.currentWidget()
        if isinstance(widget, Tab):
            return widget
        return None

    def close_tab(self, index: int):
        """Fecha tab no index e deleta memoria atrelada."""
        widget = self.widget(index)
        if isinstance(widget, Tab):
            widget.cleanup()
        self.removeTab(index)
        widget.deleteLater()
        
        # Se fechar a ultima aba, não deixamos a tela cinza.
        # MainWindow capturará currentChanged e pode pedir pra abrir uma nova.
        if self.count() == 0:
            pass # Tratado na MainWindow

    def _on_tab_changed(self, index: int):
        """Gatilho quando o usuário muda de aba ativa."""
        tab = self.get_current_tab()
        if tab:
            self.currentTabUrlChanged.emit(tab.current_url())
            title = self.tabText(index)
            self.currentTabTitleChanged.emit(title)

    def _handle_url_change(self, url: str):
        # Somente notifica a MainWindow se quem emitiu foi a aba atual visível
        if self.sender() == self.get_current_tab():
            self.currentTabUrlChanged.emit(url)
            
    def _handle_title_change(self, title: str):
        sender_tab = self.sender()
        if sender_tab:
            index = self.indexOf(sender_tab)
            if index != -1:
                prefix = "🔒 " if sender_tab.is_private else ""
                short_title = title[:20] + "..." if len(title) > 20 else title
                self.setTabText(index, f"{prefix}{short_title}")
                self.setTabToolTip(index, title)
                
            # Se for a ativa, soltar evento de janela
            if sender_tab == self.get_current_tab():
                self.currentTabTitleChanged.emit(title)
