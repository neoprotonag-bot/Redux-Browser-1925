import os
import hashlib
from typing import Optional, Dict

class CacheManager:
    """
    Gerencia cache de recursos no disco interceptando o HttpClient.
    Identifica recursos pela URL + ETag via Hash MD5 local caso não tenha ETag no Header.
    """
    def __init__(self, cache_dir: str = "~/.redux_browser/cache/"):
        self.cache_dir = os.path.expanduser(cache_dir)
        os.makedirs(self.cache_dir, exist_ok=True)
        
    def _create_filename(self, url: str) -> str:
        """Gera um arquivo MD5 curto perante a URL para o filesystem"""
        encoded = url.encode('utf-8')
        return hashlib.md5(encoded).hexdigest()

    def _get_path(self, url: str) -> str:
        return os.path.join(self.cache_dir, self._create_filename(url))

    def get_cached_resource(self, url: str) -> Optional[bytes]:
        """Tenta resgatar em disco a página ou recurso requisitado."""
        path = self._get_path(url)
        if os.path.exists(path):
            try:
                with open(path, 'rb') as f:
                    return f.read()
            except Exception:
                return None
        return None

    def store_resource(self, url: str, data: bytes, headers: Dict[str, str]):
        """Avalia heurísticas de HTTP Cache-Control antes de gravar."""
        
        # Heurísticas de Controle Reativo:
        cc = headers.get('Cache-Control', '').lower()
        if 'no-store' in cc or 'no-cache' in cc:
            # Requisito forte para nunca cachar esse call
            self.invalidate(url)
            return
            
        # Grava!
        path = self._get_path(url)
        try:
            with open(path, 'wb') as f:
                f.write(data)
        except Exception as e:
            print(f"[CacheManager] Falha ao escrever {url}: {e}")

    def invalidate(self, url: str):
        path = self._get_path(url)
        if os.path.exists(path):
            try: os.remove(path)
            except: pass

    def clear_cache(self):
        """Limpa todo o diretório de cache manual."""
        for filename in os.listdir(self.cache_dir):
            path = os.path.join(self.cache_dir, filename)
            try:
                if os.path.isfile(path): os.remove(path)
            except: pass
