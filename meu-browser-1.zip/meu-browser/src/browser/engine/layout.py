from typing import Optional, List
from dataclasses import dataclass
from browser.engine.render_tree import RenderNode

@dataclass
class Rect:
    """Retângulo básico para cálculos geométricos"""
    x: float = 0.0
    y: float = 0.0
    width: float = 0.0
    height: float = 0.0

class LayoutBox:
    """
    A caixa para o Box Model (margin, border, padding, content).
    Possui propriedades físicas na tela (absolute pos, width, height).
    """
    def __init__(self):
        self.content = Rect()
        
        # Simplificação: armazenamos como tuplas (top, right, bottom, left) ou valor fixo
        self.padding = Rect()
        self.border = Rect()
        self.margin = Rect()
        
    def total_width(self) -> float:
        """Largura total ocupada: Content + padding_h + border_h + margin_h"""
        return (self.margin.x + self.border.x + self.padding.x + 
                self.content.width + 
                self.padding.width + self.border.width + self.margin.width)
                
    def total_height(self) -> float:
        """Altura total ocupada"""
        return (self.margin.y + self.border.y + self.padding.y + 
                self.content.height + 
                self.padding.height + self.border.height + self.margin.height)

class LayoutEngine:
    """
    Responsável por calcular a dimensão e a posição (x, y) real 
    de cada nó na interface a partir da RenderTree.
    """
    def __init__(self, viewport_width: float, viewport_height: float):
        self.viewport_width = viewport_width
        self.viewport_height = viewport_height

    def layout(self, root_node: RenderNode):
        """Ponto de entrada: Cria as LayoutBoxes e calcula o layout recursivo."""
        if not root_node: return
        
        root_node.layout_box = LayoutBox()
        root_node.layout_box.content.width = self.viewport_width
        root_node.layout_box.content.x = 0
        root_node.layout_box.content.y = 0
        
        self._layout_node(root_node)

    def _parse_length(self, val: str, parent_val: float) -> float:
        """Converte px ou % para float (fallback para 0)"""
        val = val.strip().lower()
        if val.endswith('px'):
            try: return float(val[:-2])
            except: return 0.0
        elif val.endswith('%'):
            try: return (float(val[:-1]) / 100.0) * parent_val
            except: return 0.0
        return 0.0

    def _layout_node(self, node: RenderNode):
        """Passo principal de Layout para Flow Layout (Block e Inline)"""
        # Se for inicializado
        if not node.layout_box:
            node.layout_box = LayoutBox()
            
        display = node.styles.get('display', 'inline')
        
        # 1. Configura a Largura (Width)
        self._calculate_width(node)
        
        # 2. Configura a Posição XY (Flow)
        self._calculate_position(node)
        
        # 3. Faz recursão para posicionar/dimencionar os filhos
        # Para Blocos, OS filhos inline acumulam horizontalmente, os blocks desce Y
        cursor_x = node.layout_box.content.x
        cursor_y = node.layout_box.content.y
        max_child_height_inline = 0
        
        for child in node.children:
            child.layout_box = LayoutBox()
            child_display = child.styles.get('display', 'inline')
            
            # Largura preliminar para os filhos (filhos pegam proporção relativa ao pai)
            child.layout_box.content.width = node.layout_box.content.width
            
            # Para flow block: empilha
            if child_display == 'block':
                # Desce o cursor em y se tivesse algum inline e zera o x
                if cursor_x > node.layout_box.content.x:
                    cursor_y += max_child_height_inline
                    cursor_x = node.layout_box.content.x
                    max_child_height_inline = 0
                
                # Seta posição e recursão
                child.layout_box.content.x = cursor_x
                child.layout_box.content.y = cursor_y
                self._layout_node(child) # recursao vai ajustar a altura!
                
                # Avança cursor Y
                cursor_y += child.layout_box.total_height()
                
            # Para flow inline: empilha horiz, desce quando quebra linha
            else:
                self._layout_node(child)
                # Verifica quebra de linha simplificada
                if cursor_x + child.layout_box.total_width() > node.layout_box.content.x + node.layout_box.content.width:
                    cursor_y += max_child_height_inline
                    cursor_x = node.layout_box.content.x
                    max_child_height_inline = 0
                    
                child.layout_box.content.x = cursor_x
                child.layout_box.content.y = cursor_y
                
                cursor_x += child.layout_box.total_width()
                max_child_height_inline = max(max_child_height_inline, child.layout_box.total_height())

        # Adiciona ultima linha caso terminasse em inline
        if cursor_x > node.layout_box.content.x:
            cursor_y += max_child_height_inline
            
        # 4. Configura Altura (Height) baseado no conteúdo (se não fixo)
        self._calculate_height(node, cursor_y - node.layout_box.content.y)

    def _calculate_width(self, node: RenderNode):
        """Avalia a largura. Blocos expandem pra 100% (-m-b-p) salvo se tiver height fixo."""
        box = node.layout_box
        style = node.styles
        
        # Placeholder simplificado para px e %
        parent_width = node.parent.layout_box.content.width if node.parent else self.viewport_width
        
        # Margins (simplificado left/right)
        margin = style.get('margin', '0px').split()
        m_val = self._parse_length(margin[0], parent_width)
        box.margin.x = m_val # left
        box.margin.width = m_val # right
        
        # Default: Blocks preenchem tudo disponivel, Inline so o texto (trataremos no height)
        display = style.get('display', 'inline')
        if display == 'block':
            width_val = style.get('width', 'auto')
            if width_val != 'auto':
                w = self._parse_length(width_val, parent_width)
                box.content.width = w
            else:
                box.content.width = parent_width - box.margin.x - box.margin.width

    def _calculate_position(self, node: RenderNode):
        """Aplica margins horizontais e verticais a partir do x/y injetado pelo pai"""
        box = node.layout_box
        style = node.styles
        
        parent_width = node.parent.layout_box.content.width if node.parent else self.viewport_width
        margin = style.get('margin', '0px').split()
        m_val = self._parse_length(margin[0], parent_width)
        
        # Atualiza o x/y do content em si para estar dentro de margens e bordas
        box.content.x += box.margin.x
        box.content.y += m_val

    def _calculate_height(self, node: RenderNode, children_height: float):
        """Determina a altura. Inline é base font-size, Block é a prop ou a altura dos filhos."""
        box = node.layout_box
        style = node.styles
        parent_width = node.parent.layout_box.content.width if node.parent else self.viewport_width
        
        # Se for texto / auto, a altura é do conteudo (estimativa via fontSize nos nos de texto)
        if node.dom_node.tag_name == "#text":
            fs = self._parse_length(style.get('font-size', '16px'), parent_width)
            box.content.height = fs
            # largura baseada em len (simplissimo para demo)
            box.content.width = len(node.dom_node.text_content) * (fs * 0.6) 
            return
            
        height_val = style.get('height', 'auto')
        if height_val != 'auto':
            box.content.height = self._parse_length(height_val, parent_width) # em tese é em relacao a height do pai
        else:
            box.content.height = children_height

        # Se for inline sem height (eg: img, span vazio) e nao for texto
        if style.get('display', 'inline') == 'inline' and children_height == 0 and node.dom_node.tag_name != "#text":
           box.content.height = 0
