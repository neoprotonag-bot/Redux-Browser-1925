"""
Redux Browser - Randomizador de Fingerprint
Gera perfis falsos para impedir rastreamento por browser fingerprinting.
"""

import random
import hashlib
import uuid
import json
from dataclasses import dataclass, field, asdict
from typing import List, Optional, Dict
from enum import Enum

class RandomizationLevel(Enum):
    """Níveis de randomização disponíveis."""
    OFF = "off"                    # Sem randomização (dados reais)
    LIGHT = "light"                # Randomiza apenas User-Agent e idioma
    MEDIUM = "medium"              # Randomiza UA, idioma, resolução, timezone
    AGGRESSIVE = "aggressive"      # Randomiza TUDO (pode quebrar alguns sites)
    STEALTH = "stealth"            # Nível Maximo com Proteção Estatística + WebRTC + Ruídos puros
    PER_TAB = "per_tab"            # Perfil diferente para cada aba
    PER_SESSION = "per_session"    # Perfil diferente a cada reinício

@dataclass
class FingerprintProfile:
    """Perfil completo de fingerprint falso."""
    profile_id: str
    user_agent: str
    platform: str
    os_name: str
    os_version: str
    browser_name: str
    browser_version: str
    screen_width: int
    screen_height: int
    color_depth: int
    pixel_ratio: float
    timezone: str
    timezone_offset: int
    language: str
    languages: List[str]
    cpu_cores: int
    memory_gb: int
    max_touch_points: int
    webgl_vendor: str
    webgl_renderer: str
    canvas_noise_seed: str
    audio_noise_seed: str
    installed_fonts: List[str]
    plugins: List[Dict[str, str]]
    do_not_track: Optional[str]
    hardware_concurrency: int

    def to_dict(self) -> dict:
        """Converte o perfil para dicionário serializável."""
        return {
            "profile_id": self.profile_id,
            "user_agent": self.user_agent,
            "platform": self.platform,
            "os_name": self.os_name,
            "os_version": self.os_version,
            "browser_name": self.browser_name,
            "browser_version": self.browser_version,
            "screen_width": self.screen_width,
            "screen_height": self.screen_height,
            "color_depth": self.color_depth,
            "pixel_ratio": self.pixel_ratio,
            "timezone": self.timezone,
            "timezone_offset": self.timezone_offset,
            "language": self.language,
            "languages": self.languages,
            "cpu_cores": self.cpu_cores,
            "memory_gb": self.memory_gb,
            "max_touch_points": self.max_touch_points,
            "webgl_vendor": self.webgl_vendor,
            "webgl_renderer": self.webgl_renderer,
            "canvas_noise_seed": self.canvas_noise_seed,
            "audio_noise_seed": self.audio_noise_seed,
            "installed_fonts": self.installed_fonts,
            "plugins": self.plugins,
            "do_not_track": self.do_not_track,
            "hardware_concurrency": self.hardware_concurrency,
        }

    def to_js_overrides(self, level_str: str = "stealth") -> str:
        """Gera código JavaScript para injetar as propriedades falsas e proteções profundas no navegador."""
        
        js = f"""
        (function() {{
            const override = (obj, prop, value) => {{
                try {{
                    Object.defineProperty(obj, prop, {{
                        get: () => value,
                        configurable: true
                    }});
                }} catch (e) {{}}
            }};

            override(navigator, 'userAgent', '{self.user_agent}');
            override(navigator, 'platform', '{self.platform}');
            override(navigator, 'language', '{self.language}');
            override(navigator, 'languages', {str(self.languages).replace("'", '"')});
            override(navigator, 'hardwareConcurrency', {self.hardware_concurrency});
            override(navigator, 'deviceMemory', {self.memory_gb});
            override(navigator, 'maxTouchPoints', {self.max_touch_points});
            if ('{self.do_not_track}' !== 'None') {{
                override(navigator, 'doNotTrack', '{self.do_not_track}');
            }}

            override(screen, 'width', {self.screen_width});
            override(screen, 'height', {self.screen_height});
            override(screen, 'colorDepth', {self.color_depth});
            override(screen, 'pixelDepth', {self.color_depth});
            override(window, 'devicePixelRatio', {self.pixel_ratio});

            // DateTime override (Timezone Spoofing)
            const originalDate = Date;
            const tbOffset = {self.timezone_offset};
            window.Date = class extends originalDate {{
                constructor(...args) {{ super(...args); }}
                getTimezoneOffset() {{ return tbOffset; }}
            }};

            // WebGL Spoofing (Deep V2)
            const getParameterProxy = new Proxy(
                WebGLRenderingContext.prototype.getParameter, {{
                apply(target, thisArg, args) {{
                    const param = args[0];
                    if (param === 0x9245) return '{self.webgl_vendor}';
                    if (param === 0x9246) return '{self.webgl_renderer}';
                    return Reflect.apply(target, thisArg, args);
                }}
            }});
            WebGLRenderingContext.prototype.getParameter = getParameterProxy;
            if (typeof WebGL2RenderingContext !== 'undefined') {{
                WebGL2RenderingContext.prototype.getParameter = getParameterProxy;
            }}

            // Canvas Hash Noise V2 (Sutil)
            const originalToDataURL = HTMLCanvasElement.prototype.toDataURL;
            const originalToBlob = HTMLCanvasElement.prototype.toBlob;
            const originalGetImageData = CanvasRenderingContext2D.prototype.getImageData;

            function addNoise(imageData, seed) {{
                const data = imageData.data;
                const noiseSeed = parseInt(seed, 16) || 1234567;
                for (let i = 0; i < data.length; i += 4) {{
                    const noise = ((noiseSeed * (i + 1)) % 3) - 1;
                    data[i] = Math.max(0, Math.min(255, data[i] + noise));
                    data[i+1] = Math.max(0, Math.min(255, data[i+1] + noise));
                    data[i+2] = Math.max(0, Math.min(255, data[i+2] + noise));
                }}
                return imageData;
            }}

            CanvasRenderingContext2D.prototype.getImageData = function(...args) {{
                const imgData = originalGetImageData.apply(this, args);
                return addNoise(imgData, '{self.canvas_noise_seed}');
            }};

            HTMLCanvasElement.prototype.toDataURL = function(...args) {{
                const ctx = this.getContext('2d');
                if (ctx) {{
                    const img = ctx.getImageData(0, 0, this.width, this.height);
                    ctx.putImageData(addNoise(img, '{self.canvas_noise_seed}'), 0, 0);
                }}
                return originalToDataURL.apply(this, args);
            }};

            HTMLCanvasElement.prototype.toBlob = function(callback, ...args) {{
                const ctx = this.getContext('2d');
                if (ctx) {{
                    const img = ctx.getImageData(0, 0, this.width, this.height);
                    ctx.putImageData(addNoise(img, '{self.canvas_noise_seed}'), 0, 0);
                }}
                return originalToBlob.call(this, callback, ...args);
            }};

            // AudioContext Noise V2
            try {{
                const originalCreateDynamicsCompressor = window.AudioContext.prototype.createDynamicsCompressor || window.webkitAudioContext.prototype.createDynamicsCompressor;
                const spoofAudio = function() {{
                    const compressor = originalCreateDynamicsCompressor.apply(this);
                    const seed = parseInt('{self.audio_noise_seed}', 16) || 12345;
                    const noise = (seed % 100) / 10000;
                    const originalThreshold = compressor.threshold;
                    Object.defineProperty(compressor, 'threshold', {{
                        get: function() {{
                            return {{ value: originalThreshold.value + noise, ...originalThreshold }};
                        }}
                    }});
                    return compressor;
                }};
                if (window.AudioContext) window.AudioContext.prototype.createDynamicsCompressor = spoofAudio;
                if (window.webkitAudioContext) window.webkitAudioContext.prototype.createDynamicsCompressor = spoofAudio;
            }} catch(e) {{}}

            // Font Fingerprinting V2 (Limitar a lista do OS)
            const allowedFonts = {json.dumps(self.installed_fonts)};
            const originalMeasureText = CanvasRenderingContext2D.prototype.measureText;
            CanvasRenderingContext2D.prototype.measureText = function(text) {{
                const currentFont = this.font;
                const fontFamily = currentFont.split(',')[0].replace(/['"]/g, '').trim();
                if (!allowedFonts.includes(fontFamily)) {{
                    this.font = currentFont.replace(fontFamily, 'sans-serif');
                }}
                return originalMeasureText.apply(this, [text]);
            }};
        """
        
        # WebRTC apenas bloqueado em max modes para nao quebrar skypes da vida sem aviso
        if level_str in ("stealth", "aggressive"):
            js += """
            // Protecao WebRTC Local IP Leak
            if (navigator.mediaDevices && navigator.mediaDevices.enumerateDevices) {
                navigator.mediaDevices.enumerateDevices = function() {
                    return Promise.resolve([]);
                };
            }
            const OriginalRTC = window.RTCPeerConnection || window.webkitRTCPeerConnection || window.mozRTCPeerConnection;
            if (OriginalRTC) {
                window.RTCPeerConnection = function(config) {
                    if (config && config.iceServers) {
                        config.iceTransportPolicy = 'relay';
                    }
                    return new OriginalRTC(config);
                };
                window.RTCPeerConnection.prototype = OriginalRTC.prototype;
            }
            """
            
        js += """
        })();
        """
        return js

class FingerprintRandomizer:
    """
    Motor principal de randomização de fingerprint com suporte STEALTH (Probabilístico).
    """
    
    # Probabilidades baseadas em StatCounter/GlobalStats 2024
    OS_DISTRIBUTION = {
        "Windows 10": 0.42,
        "Windows 11": 0.28,
        "macOS 14": 0.10,
        "macOS 13": 0.05,
        "Linux": 0.03,
    }

    BROWSER_DISTRIBUTION = {
        "Chrome": 0.65,
        "Edge": 0.13,
        "Safari": 0.09,
        "Firefox": 0.06,
        "Opera": 0.03,
        "Brave": 0.02
    }

    RESOLUTION_DISTRIBUTION = {
        (1920, 1080): 0.38,
        (1366, 768): 0.18,
        (2560, 1440): 0.09,
        (1536, 864): 0.08,
        (1440, 900): 0.06,
        (3840, 2160): 0.05,
        (1280, 720): 0.05,
        (1600, 900): 0.04
    }

    LANGUAGE_DISTRIBUTION = {
        ("en-US", ("en-US", "en")): 0.30,
        ("zh-CN", ("zh-CN", "zh")): 0.15,
        ("es-ES", ("es-ES", "es")): 0.08,
        ("pt-BR", ("pt-BR", "pt", "en")): 0.05,
        ("de-DE", ("de-DE", "de", "en")): 0.05,
        ("fr-FR", ("fr-FR", "fr")): 0.05,
        ("ja-JP", ("ja-JP", "ja")): 0.04,
        ("en-GB", ("en-GB", "en")): 0.04
    }

    USER_AGENTS = {
        "Windows": [
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{version} Safari/537.36",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:{firefox_version}) Gecko/20100101 Firefox/{firefox_version}",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{version} Safari/537.36 Edg/{version}"
        ],
        "macOS": [
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{version} Safari/537.36",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 14.2; rv:{firefox_version}) Gecko/20100101 Firefox/{firefox_version}",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15"
        ],
        "Linux": [
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{version} Safari/537.36",
            "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:{firefox_version}) Gecko/20100101 Firefox/{firefox_version}",
        ]
    }

    CHROME_VERSIONS = ["120.0.6099.130", "121.0.6167.85", "122.0.6261.94", "123.0.6312.58", "124.0.6367.91", "125.0.6422.60"]
    FIREFOX_VERSIONS = ["121.0", "122.0", "123.0", "124.0.1", "125.0"]

    SCREEN_RESOLUTIONS = [
        (1366, 768), (1920, 1080), (2560, 1440), (3840, 2160),
        (1536, 864), (1440, 900), (1280, 720), (1600, 900)
    ]

    TIMEZONES = {
        "America/New_York": 300, "America/Chicago": 360,
        "America/Denver": 420, "America/Los_Angeles": 480,
        "America/Sao_Paulo": 180, "Europe/London": 0,
        "Europe/Paris": -60, "Europe/Berlin": -60,
        "Europe/Moscow": -180, "Asia/Tokyo": -540,
        "Australia/Sydney": -660
    }

    LANGUAGES = [
        ("en-US", ["en-US", "en"]),
        ("en-GB", ["en-GB", "en"]),
        ("pt-BR", ["pt-BR", "pt", "en-US", "en"]),
        ("es-ES", ["es-ES", "es"]),
        ("fr-FR", ["fr-FR", "fr"]),
        ("de-DE", ["de-DE", "de"]),
        ("ja-JP", ["ja-JP", "ja"])
    ]

    WEBGL_RENDERERS = [
        ("Google Inc.", "ANGLE (NVIDIA GeForce GTX 1650 Direct3D11)"),
        ("Google Inc.", "ANGLE (NVIDIA GeForce RTX 3060 Direct3D11)"),
        ("Google Inc.", "ANGLE (AMD Radeon RX 580 Direct3D11)"),
        ("Google Inc.", "ANGLE (Intel UHD Graphics 630 Direct3D11)"),
        ("Google Inc. (Apple)", "ANGLE (Apple, Apple M1, OpenGL 4.1)"),
        ("Google Inc. (Apple)", "ANGLE (Apple, Apple M2, OpenGL 4.1)"),
        ("Mesa", "Mesa Intel(R) UHD Graphics 620 (CML GT2)")
    ]

    FONT_LISTS = {
        "Windows": ["Arial", "Calibri", "Cambria", "Comic Sans MS", "Consolas", "Courier New", "Georgia", "Impact", "Segoe UI", "Tahoma", "Times New Roman", "Verdana"],
        "macOS": ["Arial", "Avenir", "Futura", "Geneva", "Helvetica", "Helvetica Neue", "Lucida Grande", "Menlo", "Monaco", "San Francisco", "Times New Roman"],
        "Linux": ["Arial", "Cantarell", "DejaVu Sans", "DejaVu Serif", "Droid Sans", "Liberation Mono", "Liberation Sans", "Noto Sans", "Roboto", "Ubuntu"]
    }

    def __init__(self, level: RandomizationLevel = RandomizationLevel.MEDIUM):
        self.level = level
        self._profiles: Dict[str, FingerprintProfile] = {}
        self._session_profile: Optional[FingerprintProfile] = None

    def generate_profile(self, tab_id: str = "default") -> FingerprintProfile:
        if self.level == RandomizationLevel.OFF:
            return self._real_profile()
            
        use_stealth = self.level in (RandomizationLevel.STEALTH, RandomizationLevel.AGGRESSIVE)
        
        # OS (Stealth mode usa peso probabilistico real)
        if use_stealth:
            os_ver = random.choices(list(self.OS_DISTRIBUTION.keys()), weights=list(self.OS_DISTRIBUTION.values()))[0]
            if "Windows" in os_ver: os_name, os_version = "Windows", "10.0"
            elif "macOS" in os_ver: os_name, os_version = "macOS", "14.2"
            else: os_name, os_version = "Linux", "x86_64"
        else:
            os_name = random.choice(["Windows", "macOS", "Linux"])
            os_version = "10.0" if os_name == "Windows" else "14.2"

        # Compatibilidade
        platform_map = {"Windows": "Win32", "macOS": "MacIntel", "Linux": "Linux x86_64"}
        platform = platform_map[os_name]
        
        # Browser Type
        if use_stealth:
            browser_type_choice = random.choices(list(self.BROWSER_DISTRIBUTION.keys()), weights=list(self.BROWSER_DISTRIBUTION.values()))[0]
            if os_name != "macOS" and browser_type_choice == "Safari": browser_type_choice = "Chrome"
        else:
            browser_type_choice = random.choice(["Chrome", "Firefox", "Safari"])
            if os_name != "macOS" and browser_type_choice == "Safari": browser_type_choice = "Chrome"
            
        ua = self._generate_consistent_ua(os_name, browser_type_choice)
        
        # Tela
        if use_stealth:
            res = random.choices(list(self.RESOLUTION_DISTRIBUTION.keys()), weights=list(self.RESOLUTION_DISTRIBUTION.values()))[0]
        else:
            res = random.choice(list(self.RESOLUTION_DISTRIBUTION.keys()))
        w, h = res
        
        # Idioma
        if use_stealth:
            lang_tuple = random.choices(list(self.LANGUAGE_DISTRIBUTION.keys()), weights=list(self.LANGUAGE_DISTRIBUTION.values()))[0]
            lang, langs = lang_tuple[0], list(lang_tuple[1])
        else:
            lang_tuple = random.choice(list(self.LANGUAGE_DISTRIBUTION.keys()))
            lang, langs = lang_tuple[0], list(lang_tuple[1])
        
        # TZ
        tz_name, tz_offset = random.choice(list(self.TIMEZONES.items()))
        
        # WebGL
        if os_name == "macOS": webgl_opts = [w for w in self.WEBGL_RENDERERS if "Apple" in w[1]]
        elif os_name == "Linux": webgl_opts = [w for w in self.WEBGL_RENDERERS if "Mesa" in w[0] or "Linux" in w[1]]
        else: webgl_opts = [w for w in self.WEBGL_RENDERERS if "Apple" not in w[1]]
        
        if not webgl_opts: webgl_opts = self.WEBGL_RENDERERS
        webgl_vendor, webgl_renderer = random.choice(webgl_opts)
        
        # Fonts
        installed_fonts = self._select_fonts_for_os(os_name)
        
        # Respeitar nives
        if self.level == RandomizationLevel.LIGHT:
            # mantém tela real ou padrao ameno
            w, h = 1920, 1080
            tz_offset = 0
            
        prof = FingerprintProfile(
            profile_id=str(uuid.uuid4()),
            user_agent=ua,
            platform=platform,
            os_name=os_name,
            os_version="10.0" if os_name == "Windows" else "14.2",
            browser_name=browser_type_choice,
            browser_version=random.choice(self.CHROME_VERSIONS) if browser_type_choice != "Firefox" else random.choice(self.FIREFOX_VERSIONS),
            screen_width=w,
            screen_height=h,
            color_depth=24,
            pixel_ratio=1.0 if w < 2000 else 2.0,
            timezone=tz_name,
            timezone_offset=tz_offset,
            language=lang,
            languages=langs,
            cpu_cores=random.choice([4, 8, 12, 16]),
            memory_gb=random.choice([8, 16, 32]),
            max_touch_points=0,
            webgl_vendor=webgl_vendor,
            webgl_renderer=webgl_renderer,
            canvas_noise_seed=self._generate_canvas_noise(str(uuid.uuid4())),
            audio_noise_seed=self._generate_audio_noise(str(uuid.uuid4())),
            installed_fonts=installed_fonts,
            plugins=self._generate_plugins(browser_type_choice),
            do_not_track=random.choice(["1", None]),
            hardware_concurrency=8
        )
        
        prof.hardware_concurrency = prof.cpu_cores
        
        if self.level == RandomizationLevel.PER_SESSION:
            if not self._session_profile:
                self._session_profile = prof
            prof = self._session_profile
            
        self._profiles[tab_id] = prof
        return prof

    def _real_profile(self) -> FingerprintProfile:
        return FingerprintProfile(
            profile_id="real", user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            platform="Win32", os_name="Windows", os_version="10.0", browser_name="Chrome", browser_version="120",
            screen_width=1920, screen_height=1080, color_depth=24, pixel_ratio=1.0, timezone="America/Sao_Paulo", timezone_offset=180,
            language="pt-BR", languages=["pt-BR", "en"], cpu_cores=8, memory_gb=16, max_touch_points=0,
            webgl_vendor="Google Inc.", webgl_renderer="ANGLE (Intel UHD Graphics)", canvas_noise_seed="", audio_noise_seed="",
            installed_fonts=[], plugins=[], do_not_track=None, hardware_concurrency=8
        )

    def get_profile(self, tab_id: str = "default") -> FingerprintProfile:
        if self.level == RandomizationLevel.OFF: return self._real_profile()
        if self.level == RandomizationLevel.PER_SESSION and self._session_profile: return self._session_profile
        
        if tab_id not in self._profiles:
            return self.generate_profile(tab_id)
        return self._profiles[tab_id]

    def regenerate_profile(self, tab_id: str = "default") -> FingerprintProfile:
        if self.level == RandomizationLevel.PER_SESSION:
            self._session_profile = None # Invalida e recria global
        return self.generate_profile(tab_id)

    def set_level(self, level: RandomizationLevel) -> None:
        self.level = level
        if level == RandomizationLevel.PER_SESSION: 
            self._session_profile = None

    def get_js_injection_script(self, tab_id: str = "default") -> str:
        if self.level == RandomizationLevel.OFF: return ""
        profile = self.get_profile(tab_id)
        return profile.to_js_overrides(self.level.value)

    def get_headers(self, tab_id: str = "default") -> Dict[str, str]:
        if self.level == RandomizationLevel.OFF: return {}
        profile = self.get_profile(tab_id)
        headers = {
            "User-Agent": profile.user_agent,
            "Accept-Language": ",".join(profile.languages),
        }
        if profile.do_not_track:
            headers["DNT"] = profile.do_not_track
        return headers

    def _generate_consistent_ua(self, os_name, browser_name) -> str:
        tpls = self.USER_AGENTS[os_name]
        selected_tpl = random.choice(tpls)
        cv = random.choice(self.CHROME_VERSIONS)
        fv = random.choice(self.FIREFOX_VERSIONS)
        return selected_tpl.replace("{version}", cv).replace("{firefox_version}", fv)

    def _generate_canvas_noise(self, seed: str) -> str:
        return hashlib.md5(seed.encode()).hexdigest()[:8]

    def _generate_audio_noise(self, seed: str) -> str:
        return hashlib.sha256(seed.encode()).hexdigest()[:8]

    def _select_fonts_for_os(self, os_name: str) -> List[str]:
        return self.FONT_LISTS.get(os_name, self.FONT_LISTS["Windows"])

    def _generate_plugins(self, browser_name: str) -> List[Dict]:
        if browser_name == "Chrome":
            return [
                {"name": "Chrome PDF Plugin", "filename": "internal-pdf-viewer", "description": "Portable Document Format"},
                {"name": "Chrome PDF Viewer", "filename": "mhjfbmdgcfjbbpaeojofohoefgiehjai", "description": ""}
            ]
        elif browser_name == "Firefox":
             return [{"name": "PDF Viewer", "filename": "pdfjs", "description": "Portable Document Format"}]
        return []
