"""
Spoofing de headers HTTP para complementar o fingerprint.
Garante que os headers enviados ao servidor sejam consistentes
com o perfil de fingerprint ativo.
"""
from typing import Dict
from .fingerprint_randomizer import FingerprintProfile

class HeaderSpoofer:
    """Gera headers HTTP consistentes com o perfil de fingerprint."""

    def generate_headers(self, profile: FingerprintProfile) -> Dict[str, str]:
        """
        Gera conjunto completo de headers baseado no perfil.
        Inclui:
        - User-Agent
        - Accept-Language (baseado no idioma do perfil)
        - Sec-CH-UA (Client Hints - baseado no browser do perfil)
        - Sec-CH-UA-Platform (baseado no OS do perfil)
        - Sec-CH-UA-Mobile (?0 para desktop, ?1 para mobile)
        - Sec-CH-UA-Full-Version-List
        - Accept (baseado no browser do perfil)
        - Accept-Encoding
        - DNT (Do Not Track - baseado no perfil)
        """
        headers = {
            "User-Agent": profile.user_agent,
            "Accept-Language": ",".join(profile.languages),
            "Sec-CH-UA-Platform": f'"{profile.os_name}"',
            "Sec-CH-UA-Mobile": "?0",
        }
        
        if profile.browser_name == "Chrome":
            headers["Sec-CH-UA"] = f'"Not A(Brand";v="99", "Google Chrome";v="{profile.browser_version.split(".")[0]}", "Chromium";v="{profile.browser_version.split(".")[0]}"'
        elif profile.browser_name == "Edge":
            headers["Sec-CH-UA"] = f'"Not A(Brand";v="99", "Microsoft Edge";v="{profile.browser_version.split(".")[0]}", "Chromium";v="{profile.browser_version.split(".")[0]}"'

        if profile.do_not_track:
            headers["DNT"] = profile.do_not_track
            
        return headers
