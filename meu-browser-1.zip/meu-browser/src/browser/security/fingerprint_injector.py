"""
Injetor de Fingerprint para QtWebEngine.
Intercepta o carregamento de páginas e injeta JavaScript
que sobrescreve propriedades do navigator/screen/window.
"""

from PyQt6.QtWebEngineCore import QWebEnginePage, QWebEngineScript
from .fingerprint_randomizer import FingerprintRandomizer, FingerprintProfile

class FingerprintInjector:
    """
    Injeta scripts de fingerprint spoofing no QtWebEngine.
    Deve ser chamado ANTES do carregamento de cada página.
    """

    def __init__(self, randomizer: FingerprintRandomizer):
        self.randomizer = randomizer

    def inject_into_page(self, page: QWebEnginePage, tab_id: str) -> None:
        """
        Injeta o script de fingerprint spoofing na página.
        Usa QWebEngineScript para rodar o JS antes de qualquer
        script da página (DocumentCreation).
        """
        js_code = self.randomizer.get_js_injection_script(tab_id)
        if not js_code: return

        script = QWebEngineScript()
        script.setName(f"redux_fingerprint_{tab_id}")
        script.setSourceCode(js_code)
        script.setInjectionPoint(QWebEngineScript.InjectionPoint.DocumentCreation)
        script.setWorldId(QWebEngineScript.ScriptWorldId.ApplicationWorld)
        script.setRunsOnSubFrames(True)

        # Remover script anterior se existir
        for s in page.scripts().toList():
            if s.name() == f"redux_fingerprint_{tab_id}":
                page.scripts().remove(s)

        page.scripts().insert(script)

    def update_http_headers(self, http_client, tab_id: str) -> None:
        """
        Atualiza os headers do HttpClient com dados do perfil falso.
        """
        headers = self.randomizer.get_headers(tab_id)
        # http_client do modo antigo tem session.headers.update
        http_client.session.headers.update(headers)
