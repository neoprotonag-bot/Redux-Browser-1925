import sys
import os

# Garante que o diretório atual está no path para imports relativos funcionarem
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from PyQt6.QtWidgets import QApplication
from browser.ui.main_window import MainWindow

def main():
    """
    Ponto de entrada principal do navegador.
    Inicializa o loop de eventos Qt e exibe a janela.
    """
    # Inicializa a aplicação Qt
    app = QApplication(sys.argv)
    
    # Metadados da aplicação
    app.setApplicationName("Redux Browser")
    app.setApplicationVersion("1.0.0")
    app.setOrganizationName("CodeSpace")
    
    # Cria e exibe a janela principal
    window = MainWindow()
    window.show()
    
    # Inicia o loop de eventos
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
