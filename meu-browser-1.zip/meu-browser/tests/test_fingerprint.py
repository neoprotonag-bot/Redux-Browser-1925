import unittest
import json
import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../src')))

from browser.security.fingerprint_randomizer import FingerprintRandomizer, RandomizationLevel
from browser.security.header_spoofing import HeaderSpoofer

class TestFingerprintRandomizer(unittest.TestCase):

    def setUp(self):
        self.randomizer = FingerprintRandomizer(level=RandomizationLevel.MEDIUM)

    def test_generate_profile_returns_complete_profile(self):
        """Testa se o perfil gerado tem todos os campos preenchidos."""
        prof = self.randomizer.generate_profile("tab1")
        self.assertIsNotNone(prof.profile_id)
        self.assertIsNotNone(prof.user_agent)
        self.assertTrue(isinstance(prof.screen_width, int))
        self.assertTrue(isinstance(prof.timezone, str))
        self.assertTrue(isinstance(prof.installed_fonts, list))

    def test_profile_consistency_windows(self):
        """Testa se perfil Windows tem UA, fontes e WebGL de Windows."""
        for _ in range(20):
            prof = self.randomizer.generate_profile()
            if prof.os_name == "Windows":
                self.assertIn("Windows", prof.user_agent)
                self.assertEqual(prof.platform, "Win32")
                self.assertNotIn("Apple", prof.webgl_renderer)
                break

    def test_profile_consistency_mac(self):
        """Testa se perfil macOS tem UA, fontes e WebGL de Mac."""
        for _ in range(20):
            prof = self.randomizer.generate_profile()
            if prof.os_name == "macOS":
                self.assertIn("Mac O", prof.user_agent)
                self.assertEqual(prof.platform, "MacIntel")
                self.assertTrue("Apple" in prof.webgl_renderer or "ANGLE" in prof.webgl_renderer)
                break

    def test_different_tabs_different_profiles(self):
        """No modo PER_TAB, cada aba deve ter perfil diferente."""
        self.randomizer.set_level(RandomizationLevel.PER_TAB)
        prof1 = self.randomizer.get_profile("tab1")
        prof2 = self.randomizer.get_profile("tab2")
        self.assertNotEqual(prof1.profile_id, prof2.profile_id)

    def test_same_session_same_profile(self):
        """No modo PER_SESSION, todas as abas da sessão têm mesmo perfil."""
        self.randomizer.set_level(RandomizationLevel.PER_SESSION)
        prof1 = self.randomizer.get_profile("tab1")
        prof2 = self.randomizer.get_profile("tab2")
        self.assertEqual(prof1.profile_id, prof2.profile_id)

    def test_js_injection_script_valid(self):
        """Testa se o JS gerado tem override de canvas e UA."""
        js = self.randomizer.get_js_injection_script("tab1")
        self.assertIn("userAgent", js)
        self.assertIn("addNoise(img", js)

    def test_headers_match_profile(self):
        """Testa se headers HTTP gerados combinam com o perfil usando HeaderSpoofer."""
        prof = self.randomizer.get_profile("tab1")
        spoofer = HeaderSpoofer()
        headers = spoofer.generate_headers(prof)
        
        self.assertEqual(headers["User-Agent"], prof.user_agent)
        self.assertEqual(headers["Sec-CH-UA-Platform"], f'"{prof.os_name}"')
        self.assertIn(prof.languages[0], headers["Accept-Language"])

    def test_level_off_returns_none(self):
        """Com nível OFF, deve retornar o profile default real cravado."""
        self.randomizer.set_level(RandomizationLevel.OFF)
        prof = self.randomizer.get_profile("tab1")
        self.assertEqual(prof.profile_id, "real")

    def test_regenerate_creates_new_profile(self):
        """Regenerar deve criar perfil diferente do anterior."""
        prof1 = self.randomizer.get_profile("tab1")
        prof2 = self.randomizer.regenerate_profile("tab1")
        self.assertNotEqual(prof1.profile_id, prof2.profile_id)

    def test_canvas_noise_different_per_profile(self):
        """Cada perfil deve ter seed de canvas diferente."""
        prof1 = self.randomizer.generate_profile("tab1")
        prof2 = self.randomizer.generate_profile("tab2")
        self.assertNotEqual(prof1.canvas_noise_seed, prof2.canvas_noise_seed)

if __name__ == '__main__':
    unittest.main()
