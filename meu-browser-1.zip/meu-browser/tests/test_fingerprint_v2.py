import unittest
import json
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../src')))

from browser.security.fingerprint_randomizer import FingerprintRandomizer, RandomizationLevel
from browser.security.header_spoofing import HeaderSpoofer


class TestFingerprintRandomizerV2(unittest.TestCase):

    def setUp(self):
        self.randomizer = FingerprintRandomizer(level=RandomizationLevel.STEALTH)

    def test_stealth_probabilities_generate_valid_os(self):
        """Testa se as probabilidades do nível Stealth não quebram ao gerar."""
        prof = self.randomizer.generate_profile("stealth_tab")
        self.assertIn(prof.os_name, ["Windows", "macOS", "Linux"])
        self.assertIsNotNone(prof.user_agent)

    def test_deep_js_injection(self):
        """Testa se as novas injeções V2 (WebGL Deep, Canvas Math, Font, WebRTC) existem no Override."""
        js = self.randomizer.get_js_injection_script("stealth_tab")
        
        # Audio Noise e Canvas 2D
        self.assertIn("createDynamicsCompressor", js)
        self.assertIn("noiseSeed", js)
        
        # WebGL Deep Proxy V2
        self.assertIn("0x9245", js)
        self.assertIn("0x9246", js)
        self.assertIn("Proxy(", js)

        # WebRTC
        self.assertIn("mediaDevices.enumerateDevices", js)
        self.assertIn("iceTransportPolicy = 'relay'", js)

    def test_off_level_maintains_real_state(self):
        """Nível OFF continua isolado e não-randomizado."""
        self.randomizer.set_level(RandomizationLevel.OFF)
        js = self.randomizer.get_js_injection_script("off_tab")
        self.assertEqual(js, "")
        
        headers = self.randomizer.get_headers("off_tab")
        self.assertEqual(headers, {})

    def test_header_spoofing_v2_consistency(self):
        """Headers HTTP gerados devem obedecer o stealth mode sem vazar configs do Host."""
        prof = self.randomizer.generate_profile()
        spoofer = HeaderSpoofer()
        headers = spoofer.generate_headers(prof)
        
        # Platform Match
        self.assertEqual(headers["Sec-CH-UA-Platform"], f'"{prof.os_name}"')
        
        # Se for linux/android/ios certificar que CH-UA Mobile bate com formato esperado
        is_mobile = "?1" if prof.os_name in ["Android", "iOS"] else "?0"
        self.assertEqual(headers["Sec-CH-UA-Mobile"], is_mobile)

if __name__ == '__main__':
    unittest.main()
