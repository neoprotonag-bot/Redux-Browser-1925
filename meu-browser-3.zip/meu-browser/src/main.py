import sys
import os

# Garante que o diretório atual está no path para imports relativos funcionarem
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# MUST register custom URL scheme BEFORE QApplication is created
from browser.extensions.ext_url_handler import register_scheme
register_scheme()

from PyQt6.QtWidgets import QApplication
from PyQt6.QtWebEngineCore import QWebEngineProfile
from browser.ui.main_window import MainWindow
from browser.extensions.ext_url_handler import ExtensionSchemeHandler
from pathlib import Path

def main():
    """
    Ponto de entrada principal do navegador.
    Inicializa o loop de eventos Qt e exibe a janela.
    """
    import traceback
    sys.excepthook = lambda t, v, tb: open('crash.log', 'w').write("".join(traceback.format_exception(t, v, tb)))
    
    # Inicializa a aplicação Qt
    app = QApplication(sys.argv)
    
    # Metadados da aplicação
    app.setApplicationName("Redux Browser")
    app.setApplicationVersion("1.0.0")
    app.setOrganizationName("CodeSpace")
    
    # Register custom URL scheme handler for extensions
    extensions_dir = Path(os.path.expanduser("~/.redux_browser/extensions"))
    ext_handler = ExtensionSchemeHandler(extensions_dir)
    profile = QWebEngineProfile.defaultProfile()
    profile.installUrlSchemeHandler(b"redux-ext", ext_handler)
    
    # Cria e exibe a janela principal
    window = MainWindow()
    window._ext_scheme_handler = ext_handler  # keep reference
    window.show()
    
    # Inicia o loop de eventos
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
