"""
Redux Browser - Sistema de Farbling (inspirado no Brave Browser)

Ao invés de BLOQUEAR APIs de fingerprinting, FARBLA (altera sutilmente)
os valores retornados. Isso faz o browser parecer um browser normal
com fingerprint diferente a cada sessão.

Referência: https://brave.com/privacy-updates/3-fingerprint-randomization/

Princípios:
1. FARBLING, não blocking — retornar valores reais + ruído sutil
2. DETERMINISMO por sessão+domínio — consistência para não quebrar sites
3. NUNCA retornar valores impossíveis — não ter 0 plugins, 0 vozes, etc.
4. Proteger contra detecção — toString retorna [native code]
"""

import hashlib
import hmac
import os
import struct
from typing import Optional
from enum import Enum


class FarblingLevel(Enum):
    """
    Níveis de farbling (mesma nomenclatura do Brave).
    OFF = sem proteção
    BALANCED = proteção padrão (recomendado)
    MAXIMUM = máxima proteção (pode quebrar alguns sites)
    """
    OFF = "off"
    BALANCED = "balanced"
    MAXIMUM = "maximum"


class FarblingEngine:
    """
    Motor de farbling do Redux Browser.
    
    Gera seeds determinísticas por (session_key + domain) para que:
    - Mesmo site na mesma sessão = mesmo resultado (não quebra sites)
    - Mesmo site em sessão diferente = resultado diferente (anti-tracking)
    - Sites diferentes na mesma sessão = resultados diferentes (anti-correlação)
    """

    def __init__(self, level: FarblingLevel = FarblingLevel.BALANCED):
        self.level = level
        # Chave de sessão: gerada ao iniciar o browser, perdida ao fechar
        self._session_key: bytes = os.urandom(32)

    def get_domain_seed(self, domain: str) -> bytes:
        """
        Gera seed determinística para um domínio específico.
        Mesma sessão + mesmo domínio = mesma seed.
        """
        return hmac.new(
            self._session_key,
            domain.encode('utf-8'),
            hashlib.sha256
        ).digest()

    def get_farbling_value(self, domain: str, parameter: str) -> float:
        """
        Retorna um valor de farbling entre -1.0 e 1.0
        determinístico para (domain + parameter).
        """
        seed = self.get_domain_seed(domain)
        param_hash = hashlib.sha256(
            seed + parameter.encode()
        ).digest()
        value = struct.unpack('I', param_hash[:4])[0]
        return (value / 0xFFFFFFFF) * 2 - 1

    def generate_farbling_script(self, domain: str) -> str:
        """
        Gera o JavaScript de farbling para um domínio específico.
        
        IMPORTANTE: Este script NÃO bloqueia APIs.
        Ele apenas adiciona RUÍDO SUTIL aos valores retornados.
        """
        if self.level == FarblingLevel.OFF:
            return ""

        seed = self.get_domain_seed(domain)
        seed_hex = seed.hex()

        script = self._build_balanced_js(seed_hex)

        if self.level == FarblingLevel.MAXIMUM:
            script += self._build_maximum_js(seed_hex)

        return script

    def _build_balanced_js(self, seed_hex: str) -> str:
        """
        JavaScript de farbling nível BALANCED.
        Adiciona ruído mínimo — suficiente para mudar hashes
        mas não suficiente para ser detectado visualmente.
        """
        return f'''(function() {{
    'use strict';

    // ================================================
    // REDUX BROWSER - FARBLING ENGINE (Brave-style)
    // ================================================

    const SEED = BigInt("0x{seed_hex}");

    // PRNG determinístico (xorshift64)
    let _state = SEED;
    function prng() {{
        _state ^= _state << 13n;
        _state ^= _state >> 7n;
        _state ^= _state << 17n;
        _state = _state & 0xFFFFFFFFFFFFFFFFn;
        return Number(_state & 0x7FFFFFFFn) / 0x7FFFFFFF;
    }}

    function farblingNoise(magnitude) {{
        return (prng() * 2 - 1) * magnitude;
    }}

    // ================================================
    // 1. CANVAS FARBLING (ruído de ±2 por canal)
    // ================================================

    const _origGetImageData = CanvasRenderingContext2D.prototype.getImageData;
    CanvasRenderingContext2D.prototype.getImageData = function() {{
        const imageData = _origGetImageData.apply(this, arguments);
        _state = SEED ^ BigInt(imageData.width * imageData.height);
        const data = imageData.data;
        const len = Math.min(data.length, 4 * 100 * 100);
        for (let i = 0; i < len; i += 4) {{
            data[i]   = Math.max(0, Math.min(255, data[i]   + Math.round(farblingNoise(2))));
            data[i+1] = Math.max(0, Math.min(255, data[i+1] + Math.round(farblingNoise(2))));
            data[i+2] = Math.max(0, Math.min(255, data[i+2] + Math.round(farblingNoise(2))));
        }}
        return imageData;
    }};

    const _origToDataURL = HTMLCanvasElement.prototype.toDataURL;
    HTMLCanvasElement.prototype.toDataURL = function() {{
        try {{
            const ctx = this.getContext('2d');
            if (ctx && this.width > 0 && this.height > 0) {{
                const img = ctx.getImageData(0, 0, this.width, this.height);
                ctx.putImageData(img, 0, 0);
            }}
        }} catch(e) {{}}
        return _origToDataURL.apply(this, arguments);
    }};

    const _origToBlob = HTMLCanvasElement.prototype.toBlob;
    HTMLCanvasElement.prototype.toBlob = function(cb) {{
        try {{
            const ctx = this.getContext('2d');
            if (ctx && this.width > 0 && this.height > 0) {{
                const img = ctx.getImageData(0, 0, this.width, this.height);
                ctx.putImageData(img, 0, 0);
            }}
        }} catch(e) {{}}
        return _origToBlob.apply(this, arguments);
    }};

    // ================================================
    // 2. WEBGL FARBLING
    //    Brave balanced: retorna valores reais
    //    (NÃO substituir vendor/renderer - detectável!)
    // ================================================

    function patchWebGL(proto) {{
        const _origGetParam = proto.getParameter;
        proto.getParameter = function(pname) {{
            const result = _origGetParam.call(this, pname);
            if (typeof result === 'number' && result > 0) {{
                return result;
            }}
            return result;
        }};
    }}

    if (window.WebGLRenderingContext) {{
        patchWebGL(WebGLRenderingContext.prototype);
    }}
    if (window.WebGL2RenderingContext) {{
        patchWebGL(WebGL2RenderingContext.prototype);
    }}

    // ================================================
    // 3. AUDIO FARBLING (~0.0001 ruído)
    // ================================================

    if (window.AudioContext || window.webkitAudioContext) {{
        const _OrigAC = window.AudioContext || window.webkitAudioContext;
        const _origCreateAnalyser = _OrigAC.prototype.createAnalyser;

        _OrigAC.prototype.createAnalyser = function() {{
            const analyser = _origCreateAnalyser.call(this);
            const _origGetFloat = analyser.getFloatFrequencyData.bind(analyser);

            analyser.getFloatFrequencyData = function(array) {{
                _origGetFloat(array);
                _state = SEED ^ 0xAUD10n;
                for (let i = 0; i < array.length; i++) {{
                    array[i] += farblingNoise(0.0001);
                }}
            }};

            return analyser;
        }};
    }}

    // ================================================
    // 4. FONT FARBLING (measureText ±0.1px)
    //    NÃO bloqueia fontes!
    // ================================================

    const _origMeasureText = CanvasRenderingContext2D.prototype.measureText;
    CanvasRenderingContext2D.prototype.measureText = function(text) {{
        const metrics = _origMeasureText.call(this, text);
        const realWidth = metrics.width;
        _state = SEED ^ BigInt(text.length);
        const noise = farblingNoise(0.1);

        return new Proxy(metrics, {{
            get(target, prop) {{
                if (prop === 'width') return realWidth + noise;
                const val = target[prop];
                if (typeof val === 'number') return val + noise * 0.5;
                return val;
            }}
        }});
    }};

    // ================================================
    // 5. SCREEN/WINDOW DIMENSIONS
    //    Brave balanced: NÃO altera (detectável!)
    // ================================================

    // (deliberadamente vazio no modo balanced)

    // ================================================
    // 6. PROTEGER toString de funções modificadas
    // ================================================

    const modifiedFns = [
        [CanvasRenderingContext2D.prototype, 'getImageData'],
        [CanvasRenderingContext2D.prototype, 'measureText'],
        [HTMLCanvasElement.prototype, 'toDataURL'],
        [HTMLCanvasElement.prototype, 'toBlob'],
    ];

    modifiedFns.forEach(function(pair) {{
        const obj = pair[0], name = pair[1];
        if (obj[name]) {{
            const fn = obj[name];
            fn.toString = function() {{ return 'function ' + name + '() {{ [native code] }}'; }};
            fn.toLocaleString = fn.toString;
        }}
    }});

}})();
'''

    def _build_maximum_js(self, seed_hex: str) -> str:
        """
        Proteções adicionais para nível MAXIMUM.
        Pode quebrar alguns sites mas oferece proteção extra.
        """
        return f'''
(function() {{
    'use strict';

    // ================================================
    // MODO MAXIMUM - Proteções adicionais
    // ================================================

    // WebRTC: forçar relay (sem IP leak)
    if (window.RTCPeerConnection) {{
        const _OrigRTC = window.RTCPeerConnection;
        window.RTCPeerConnection = function(cfg, constraints) {{
            cfg = cfg || {{}};
            cfg.iceTransportPolicy = 'relay';
            return new _OrigRTC(cfg, constraints);
        }};
        window.RTCPeerConnection.prototype = _OrigRTC.prototype;
    }}

    // Battery: valores genéricos via proxy (não bloquear!)
    if (navigator.getBattery) {{
        const _origBattery = navigator.getBattery.bind(navigator);
        navigator.getBattery = function() {{
            return _origBattery().then(function(battery) {{
                return new Proxy(battery, {{
                    get(target, prop) {{
                        if (prop === 'charging') return true;
                        if (prop === 'level') return 1.0;
                        if (prop === 'chargingTime') return 0;
                        if (prop === 'dischargingTime') return Infinity;
                        const val = target[prop];
                        return typeof val === 'function' ? val.bind(target) : val;
                    }}
                }});
            }});
        }};
    }}

}})();
'''

    def reset_session(self):
        """Gera nova chave de sessão (regenera todos os fingerprints)."""
        self._session_key = os.urandom(32)

    def get_spoofed_user_agent(self, domain: str) -> Optional[str]:
        """
        No modo BALANCED: retorna None (usa UA real).
        No modo MAXIMUM: retorna None (UA real é mais seguro).
        
        IMPORTANTE: O Brave no modo balanced NÃO muda o User-Agent!
        Mudar o UA é facilmente detectável e causa mais problemas.
        """
        return None
