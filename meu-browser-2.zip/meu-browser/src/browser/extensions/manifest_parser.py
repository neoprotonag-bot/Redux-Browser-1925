"""
Redux Browser — Parser de manifest.json (Manifest V2 e V3)
Lê o manifest.json de uma extensão Chrome e cria um objeto Extension.
"""

import json
import hashlib
from pathlib import Path
from typing import List, Dict, Any
from .extension_model import Extension, ManifestVersion, ContentScript, ActionConfig, Permission

class ManifestParser:
    REQUIRED_FIELDS = ["name", "version", "manifest_version"]
    
    SUPPORTED_PERMISSIONS = [
        "activeTab", "alarms", "bookmarks", "browsingData",
        "clipboardRead", "clipboardWrite", "contextMenus",
        "cookies", "downloads", "history", "notifications",
        "scripting", "storage", "tabs", "webNavigation",
        "webRequest", "declarativeNetRequest"
    ]
    
    def parse(self, manifest_path: Path) -> Extension:
        """
        Lê e parseia o manifest.json, retornando um objeto Extension.
        Converte Manifest V2 para V3 internamente.
        """
        if not manifest_path.exists():
            raise FileNotFoundError(f"manifest.json não encontrado em {manifest_path}")
            
        with open(manifest_path, 'r', encoding='utf-8') as f:
            try:
                data = json.load(f)
            except json.JSONDecodeError:
                raise ValueError("manifest.json contém JSON inválido.")
                
        # Valida campos requeridos
        for field in self.REQUIRED_FIELDS:
            if field not in data:
                raise ValueError(f"Campo obrigatório faltando no manifest.json: {field}")
                
        ext = Extension(
            id=data.get("key", self._generate_extension_id(manifest_path.parent)),
            name=data["name"],
            version=data["version"]
        )
        ext.path = manifest_path.parent
        ext.description = data.get("description", "")
        ext.author = data.get("author", "")
        ext.homepage_url = data.get("homepage_url", "")
        
        ext.manifest_version = ManifestVersion.V2 if data["manifest_version"] == 2 else ManifestVersion.V3
        
        ext.icons = data.get("icons", {})
        
        ext.content_scripts = self._parse_content_scripts(data.get("content_scripts", []))
        
        # Converte actions V2 -> V3
        if "action" in data:
            ext.action = self._parse_action(data["action"], 3)
        elif "browser_action" in data:
            ext.action = self._parse_action(data["browser_action"], 2)
        elif "page_action" in data:
            ext.action = self._parse_action(data["page_action"], 2)
            
        if "background" in data:
            ext.background = self._parse_background(data["background"], data["manifest_version"])
            
        ext.options_page = data.get("options_page")
        ext.options_ui = data.get("options_ui")
        
        # Permissões
        ext.permissions = self._parse_permissions(data.get("permissions", []))
        ext.optional_permissions = self._parse_permissions(data.get("optional_permissions", []))
        
        if "host_permissions" in data:
            ext.host_permissions = data["host_permissions"]
        elif ext.manifest_version == ManifestVersion.V2:
            # Em V2, host_permissions ficavam misturadas em permissions
            host_perms = [p for p in data.get("permissions", []) if "://" in p or p == "<all_urls>"]
            ext.host_permissions = host_perms
            
        ext.web_accessible_resources = data.get("web_accessible_resources", [])
        
        return ext
    
    def _parse_content_scripts(self, data: list) -> List[ContentScript]:
        scripts = []
        for cs in data:
            scripts.append(ContentScript(
                matches=cs.get("matches", []),
                js=cs.get("js", []),
                css=cs.get("css", []),
                run_at=cs.get("run_at", "document_idle"),
                all_frames=cs.get("all_frames", False),
                exclude_matches=cs.get("exclude_matches", []),
                match_about_blank=cs.get("match_about_blank", False)
            ))
        return scripts
    
    def _parse_action(self, data: dict, manifest_v: int) -> ActionConfig:
        config = ActionConfig()
        if "default_popup" in data: config.default_popup = data["default_popup"]
        if "default_title" in data: config.default_title = data["default_title"]
        if "default_icon" in data:
            if isinstance(data["default_icon"], str):
                config.default_icon = {"16": data["default_icon"]}
            else:
                config.default_icon = data["default_icon"]
        return config
    
    def _parse_permissions(self, perm_list: list) -> List[Permission]:
        perms = []
        for p in perm_list:
            if "://" in p or p == "<all_urls>":
                continue # Em V2 eram urls. V3 usa host_permissions
            
            supported = p in self.SUPPORTED_PERMISSIONS
            perms.append(Permission(name=p, granted=supported))
        return perms
    
    def _parse_background(self, data: dict, manifest_v: int) -> dict:
        if manifest_v == 2 and "scripts" in data:
            return {"service_worker": data["scripts"][0], "type": "module"}
        return data
    
    def _generate_extension_id(self, path: Path) -> str:
        # Chrome usa os primeiros 16 bytes do hash sha256 do app_id ou cert
        # Aqui, vamos criar hash do absolute path pra ter persistência local
        m = hashlib.sha256()
        m.update(str(path.absolute()).encode('utf-8'))
        raw_hash = m.digest()[:16]
        
        # Converter os bytes puros para range de caracteres a-p (base 16 customizada do Chrome)
        # Ex: 0x0 -> 'a', 0xf -> 'p'
        ext_id = ""
        for b in raw_hash:
            ext_id += chr(97 + (b >> 4))   # a-p
            ext_id += chr(97 + (b & 0x0F)) # a-p
        return ext_id
    
    def validate(self, extension: Extension) -> List[str]:
        warnings = []
        for p in extension.permissions:
            if not p.granted:
                warnings.append(f"Permissão não suportada pelo Redux Browser: {p.name}")
        return warnings
