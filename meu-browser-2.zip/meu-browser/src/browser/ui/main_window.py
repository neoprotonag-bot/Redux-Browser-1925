from PyQt6.QtCore import QUrl, Qt, QTimer, QPoint
from PyQt6.QtWidgets import (
    QMainWindow, QToolBar, QLineEdit, QStatusBar, 
    QVBoxLayout, QHBoxLayout, QWidget, QComboBox, QMessageBox, QMenu, QToolButton, QLabel
)
from PyQt6.QtGui import QAction, QIcon, QPixmap
import base64
from typing import Optional

from PyQt6.QtWebChannel import QWebChannel
from PyQt6.QtCore import pyqtSlot, QObject
from PyQt6.QtWidgets import QFileDialog

from browser.extensions.extension_manager import ExtensionManager
from browser.extensions.content_script_loader import ContentScriptLoader
from browser.ui.extension_toolbar import ExtensionToolbar
from browser.ui.extension_page import ExtensionPageGenerator

from browser.history.history_manager import HistoryManager
from browser.bookmarks.bookmark_manager import BookmarkManager
from browser.ui.bookmarks_bar import BookmarksBar
from browser.ui.history_dialog import HistoryDialog
from browser.ui.bookmarks_dialog import BookmarksDialog
from browser.cache.cache_manager import CacheManager
from browser.ui.tab_widget import TabWidget
from browser.ui.dom_viewer import DOMViewer

from browser.security.brave_farbling import FarblingEngine, FarblingLevel
from browser.security.farbling_injector import FarblingInjector
from browser.ui.fingerprint_panel import FingerprintPanel
from browser.ui.theme import Theme
from browser.ui.icons import Icons


class MainWindow(QMainWindow):
    """
    Janela Principal do Redux Browser - Redesign Minimalista
    """
    def __init__(self, is_private=False, history_mgr=None, bookmark_mgr=None, cache_mgr=None):
        super().__init__()
        self.is_private = is_private
        
        self.history_manager = history_mgr or HistoryManager()
        self.bookmark_manager = bookmark_mgr or BookmarkManager()
        self.cache_manager = cache_mgr or CacheManager()
        
        # Security: Farbling (Brave-style)
        self.farbling_engine = FarblingEngine()
        if self.is_private:
            self.farbling_engine.level = FarblingLevel.MAXIMUM
        self.farbling_injector = FarblingInjector(self.farbling_engine)
        
        private_str = " (Privado)" if self.is_private else ""
        self.setWindowTitle(f"Redux Browser{private_str}")
        self.setMinimumSize(1024, 768)
        
        self.current_theme = "dark"
        self.apply_theme()
        
        self.extension_manager = ExtensionManager(self)
        self.content_script_loader = ContentScriptLoader(self.extension_manager)
        self.ext_page_gen = ExtensionPageGenerator(self.extension_manager)
        
        self._init_pages()
        
        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)
        self.layout = QVBoxLayout(self.central_widget)
        self.layout.setContentsMargins(0, 0, 0, 0)
        self.layout.setSpacing(0)
        
        self.active_engine = 0
        self.setup_ui()
        
    def _create_icon(self, svg_str: str, color_override: str = None) -> QIcon:
        """Helper para criar QIcon a partir de string SVG, injetando a cor correta."""
        
        # Pega a cor correspondente ao tema
        if color_override:
            color = color_override
        else:
            palette = Theme.DARK if self.current_theme == "dark" else Theme.LIGHT
            color = palette["text_secondary"]
            
        # Altera 'currentColor' na string SVG pelo HEX correto
        svg_colored = svg_str.replace('currentColor', color)
        
        pixmap = QPixmap()
        pixmap.loadFromData(svg_colored.encode('utf-8'), "SVG")
        return QIcon(pixmap)

    def apply_theme(self):
        """Aplica o TEMA escuro/claro."""
        palette = Theme.DARK if self.current_theme == "dark" else Theme.LIGHT
        self.setStyleSheet(Theme.generate_qss(palette))
        if self.is_private:
            # Sutil override para modo privado na toolbar
            bg = "#0D0D1A" if self.current_theme == "dark" else "#F0F0F5"
            border = "#2A2A4A" if self.current_theme == "dark" else "#E0E0E5"
            self.setStyleSheet(self.styleSheet() + f"QToolBar {{ background-color: {bg}; border-bottom: 1px solid {border}; }}")
            
        if hasattr(self, 'floating_status'):
            self.floating_status.setStyleSheet(f"QLabel {{ background-color: {palette['bg_secondary']}; color: {palette['text_secondary']}; border: 1px solid {palette['border']}; border-radius: 6px; padding: 4px 12px; font-size: 11px; }}")
            
        if hasattr(self, 'dom_viewer'):
            self.dom_viewer.apply_theme(self.current_theme)
            
        if hasattr(self, 'home_html'):
            self._init_pages()

    def _init_pages(self):
        """Nova about:home Minimalista"""
        bg_class = ' class="light-theme"' if self.current_theme == 'light' else ''
        self.home_html = """
        <!DOCTYPE html>
        <html>
        <head>
            <title>Redux Browser</title>
            <style>
                * { box-sizing: border-box; margin: 0; padding: 0; }
                body {
                    background: radial-gradient(circle at center, #111111 0%, #0A0A0A 100%);
                    color: #E8E8E8; font-family: 'Segoe UI', system-ui, sans-serif;
                    height: 100vh; display: flex; flex-direction: column;
                    align-items: center; justify-content: center;
                }
                .logo-container {
                    display: flex; flex-direction: column; align-items: center;
                    margin-bottom: 40px;
                }
                .logo {
                    width: 80px; height: 80px; background: rgba(255, 59, 59, 0.15);
                    border-radius: 50%; display: flex; align-items: center; justify-content: center;
                    font-size: 40px; font-weight: 700; color: #FF3B3B; margin-bottom: 16px;
                }
                h1 { font-size: 28px; font-weight: 600; letter-spacing: -0.5px; }
                .search-box-container {
                    position: relative; width: 560px; max-width: 80%; margin-bottom: 60px;
                }
                .search-box {
                    width: 100%; height: 44px; background: #141414;
                    border: 1px solid #1F1F1F; border-radius: 12px;
                    padding: 0 16px 0 44px; font-size: 14px; color: #E8E8E8;
                    outline: none; transition: 150ms ease-out;
                }
                .search-box:focus {
                    border-color: rgba(255, 59, 59, 0.4);
                    box-shadow: 0 0 0 3px rgba(255, 59, 59, 0.15);
                }
                .search-icon {
                    position: absolute; left: 16px; top: 14px; width: 16px; height: 16px;
                    opacity: 0.5; pointer-events: none;
                }
                .speed-dial {
                    display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px;
                }
                .card {
                    width: 80px; height: 80px; background: #141414;
                    border: 1px solid #1F1F1F; border-radius: 12px;
                    display: flex; flex-direction: column; align-items: center; justify-content: center;
                    text-decoration: none; transition: 150ms ease-out;
                }
                .card:hover {
                    border-color: #333333; transform: scale(1.05);
                }
                .card-icon { font-size: 24px; color: #E8E8E8; margin-bottom: 8px; font-weight: 600; }
                .card-label { font-size: 11px; color: #888888; }
                .footer {
                    position: absolute; bottom: 20px; font-size: 12px; color: #555555;
                }
                
                /* Tema Claro Dinâmico */
                body.light-theme { background: radial-gradient(circle at center, #F7F7F7 0%, #FFFFFF 100%); color: #1A1A1A; }
                body.light-theme .search-box, body.light-theme .card { background: #FFFFFF; border-color: #E5E5E5; color: #1A1A1A; }
                body.light-theme .card-icon { color: #1A1A1A; }
                body.light-theme .card:hover { border-color: #CCCCCC; }
            </style>
        </head>
        <body""" + bg_class + """>
            <div class="logo-container">
                <div class="logo">R</div>
                <h1>Redux Browser</h1>
            </div>
            
            <form action="https://www.google.com/search" method="get" class="search-box-container">
                <svg class="search-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                <input type="text" name="q" class="search-box" placeholder="Pesquisar na web ou digitar URL" autofocus autocomplete="off" />
            </form>
            
            <div class="speed-dial">
                <a href="https://google.com" class="card">
                    <div class="card-icon" style="color: #4285F4;">G</div>
                    <div class="card-label">Google</div>
                </a>
                <a href="https://youtube.com" class="card">
                    <div class="card-icon" style="color: #FF0000;">Y</div>
                    <div class="card-label">YouTube</div>
                </a>
                <a href="https://github.com" class="card">
                    <div class="card-icon">GH</div>
                    <div class="card-label">GitHub</div>
                </a>
                <a href="https://reddit.com" class="card">
                    <div class="card-icon" style="color: #FF4500;">R</div>
                    <div class="card-label">Reddit</div>
                </a>
            </div>
            
            <div class="footer">Redux Browser v0.6 • Seu navegador.</div>
        </body>
        </html>
        """
        self.error_html = """
        <html>
        <head><style>body{background:#0A0A0A;color:#FF4444;font-family:sans-serif;text-align:center;padding:100px;}</style></head>
        <body><h2>Falha na conexão</h2><p>Verifique a internet e a URL.</p></body>
        </html>
        """

    def setup_ui(self):
        # -- TOOLBAR --
        self.toolbar = QToolBar("Navegação")
        self.toolbar.setMovable(False)
        self.addToolBar(self.toolbar)
        
        # Botões
        self.back_btn = QAction(self._create_icon(Icons.BACK), "", self)
        self.back_btn.setShortcut("Alt+Left")
        self.back_btn.triggered.connect(self.navigate_back)
        self.toolbar.addAction(self.back_btn)
        
        self.forward_btn = QAction(self._create_icon(Icons.FORWARD), "", self)
        self.forward_btn.setShortcut("Alt+Right")
        self.forward_btn.triggered.connect(self.navigate_forward)
        self.toolbar.addAction(self.forward_btn)
        
        self.reload_btn = QAction(self._create_icon(Icons.RELOAD), "", self)
        self.reload_btn.setShortcut("F5")
        self.reload_btn.triggered.connect(self.reload_page)
        self.toolbar.addAction(self.reload_btn)

        # Container flexível para a Action Bar
        spacer_left = QWidget(); spacer_left.setFixedWidth(4)
        self.toolbar.addWidget(spacer_left)
        
        # Address Bar
        self.url_bar = QLineEdit()
        self.url_bar.setObjectName("addressBar")
        self.url_bar.setPlaceholderText("Pesquisar ou digitar URL")
        self.url_bar.returnPressed.connect(self.navigate_to_url)
        # Ao colar/digitar url, limpo. Mas precisamos simular o dropdown nativamente depois.
        self.toolbar.addWidget(self.url_bar)
        
        # Ações à direita da URL
        spacer_right = QWidget(); spacer_right.setFixedWidth(4)
        self.toolbar.addWidget(spacer_right)
        
        self.fav_btn = QAction(self._create_icon(Icons.STAR), "", self)
        self.fav_btn.triggered.connect(self.toggle_bookmark)
        self.toolbar.addAction(self.fav_btn)
        
        self.shield_btn = QAction(self._create_icon(Icons.SHIELD), "", self)
        self.shield_btn.triggered.connect(self.show_fingerprint_panel)
        self.toolbar.addAction(self.shield_btn)
        
        self.extension_toolbar = ExtensionToolbar(self.extension_manager, self)
        self.toolbar.addWidget(self.extension_toolbar)
        
        # O botão do Menu
        self.menu_btn = QToolButton()
        self.menu_btn.setIcon(self._create_icon(Icons.MENU))
        self.menu_btn.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        self.menu_btn.setMenu(self._create_dropdown_menu())
        self.toolbar.addWidget(self.menu_btn)
        
        # Global Shortcuts invisiveis (Focar URL, Fechar Aba)
        self.focus_url_btn = QAction("Focar URL", self)
        self.focus_url_btn.setShortcut("Ctrl+L")
        self.focus_url_btn.triggered.connect(self.url_bar.setFocus)
        self.addAction(self.focus_url_btn)
        
        self.close_tab_btn = QAction("Fechar Aba", self)
        self.close_tab_btn.setShortcut("Ctrl+W")
        self.close_tab_btn.triggered.connect(self.close_current_tab)
        self.addAction(self.close_tab_btn)
        
        # -- BARRA DE FAVORITOS E MENUS EXTRAS --
        self.bookmarks_bar = BookmarksBar(self.bookmark_manager)
        self.bookmarks_bar.bookmarkClicked.connect(self._load_network_url)
        self.bookmarks_bar.manageRequested.connect(self.show_bookmarks)
        self.bookmarks_bar.hide() # Escondido por padrão como pedido
        self.layout.addWidget(self.bookmarks_bar)
        
        # -- TABS --
        self.tab_widget = TabWidget(self.history_manager, self.farbling_injector)
        self.tab_widget.currentTabUrlChanged.connect(self.update_url_bar)
        self.tab_widget.currentTabTitleChanged.connect(self.update_title)
        
        # Conectar hover events das abas para a statusBar flutuante
        self.tab_widget.hoveredUrlChanged.connect(self.show_floating_status)
        self.layout.addWidget(self.tab_widget)
        
        # -- DEVTOOLS PANE --
        self.dom_viewer = DOMViewer(self)
        self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, self.dom_viewer)
        self.dom_viewer.hide()
        
        # F12 atalho
        self.devtools_btn = QAction("DevTools", self)
        self.devtools_btn.setShortcut("F12")
        self.devtools_btn.triggered.connect(self.toggle_devtools)
        self.addAction(self.devtools_btn)
        
        # Floating Status Bar
        self.floating_status = QLabel(self.centralWidget())
        self.floating_status.setStyleSheet("""
            QLabel {
                background-color: #141414; color: #888888;
                border: 1px solid #1F1F1F; border-radius: 6px;
                padding: 4px 12px; font-size: 11px;
            }
        """)
        self.floating_status.hide()
        # Timer para esconder label flutuante
        self.status_timer = QTimer()
        self.status_timer.setSingleShot(True)
        self.status_timer.timeout.connect(self.floating_status.hide)
        
        self.new_tab()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        # Mantém a status bar flutuante no bottom-left
        self.floating_status.move(10, self.centralWidget().height() - self.floating_status.height() - 10)

    def show_floating_status(self, text: str):
        if text:
            self.floating_status.setText(text)
            self.floating_status.adjustSize()
            self.floating_status.move(10, self.centralWidget().height() - self.floating_status.height() - 10)
            self.floating_status.show()
            self.floating_status.raise_()
            self.status_timer.start(2000)
        else:
            self.floating_status.hide()

    def _create_dropdown_menu(self) -> QMenu:
        menu = QMenu(self)
        
        a1 = menu.addAction("Nova Aba\tCtrl+T")
        a1.triggered.connect(self.new_tab)
        
        a2 = menu.addAction(self._create_icon(Icons.PRIVATE), "Nova Janela Privada\tCtrl+Shift+P")
        a2.triggered.connect(self.open_private_window)
        
        menu.addSeparator()
        
        a3 = menu.addAction(self._create_icon(Icons.HISTORY), "Histórico\tCtrl+H")
        a3.triggered.connect(self.show_history)
        
        a4 = menu.addAction(self._create_icon(Icons.STAR), "Favoritos\tCtrl+Shift+B")
        a4.triggered.connect(self.show_bookmarks) # Shortcut real
        
        a5 = menu.addAction(self._create_icon(Icons.DOWNLOAD), "Downloads\tCtrl+J")
        # TODO downloads
        
        menu.addSeparator()
        
        a6 = menu.addAction(self._create_icon(Icons.SHIELD), "Fingerprint\tCtrl+Shift+F")
        a6.triggered.connect(self.show_fingerprint_panel)
        
        ext_menu = menu.addMenu(self._create_icon(Icons.SHIELD), "Extensões")
        ext_menu.addAction("Gerenciar Extensões", self.show_extensions)
        ext_menu.addAction("Carregar descompactada...", self.install_extension_unpacked)
        ext_menu.addAction("Instalar .crx...", self.install_extension_crx)
        
        a7 = menu.addAction("DevTools\tF12")
        a7.triggered.connect(self.toggle_devtools)
        
        menu.addSeparator()
        
        self.theme_action = menu.addAction(self._create_icon(Icons.SUN), "Tema Claro")
        self.theme_action.triggered.connect(self.toggle_theme)
        
        menu.addSeparator()
        menu.addAction("Sobre o Redux Browser")
        
        # Adicionar atalho p Bookmarks bar escondida
        toggle_bb = QAction("Toggle BB", self)
        toggle_bb.setShortcut("Ctrl+Shift+B")
        toggle_bb.triggered.connect(lambda: self.bookmarks_bar.setVisible(not self.bookmarks_bar.isVisible()))
        self.addAction(toggle_bb)
        
        return menu

    def toggle_theme(self):
        if self.current_theme == "dark":
            self.current_theme = "light"
            self.theme_action.setText("Tema Escuro")
            self.theme_action.setIcon(self._create_icon(Icons.MOON))
        else:
            self.current_theme = "dark"
            self.theme_action.setText("Tema Claro")
            self.theme_action.setIcon(self._create_icon(Icons.SUN))
        self.apply_theme()

    def toggle_bookmark(self):
        url = self.url_bar.text()
        title = self.windowTitle().replace(" - Redux Browser", "")
        # Toggle logica simplificada
        if self.bookmark_manager.is_bookmarked(url):
            self.bookmark_manager.remove_bookmark(url)
            self.fav_btn.setIcon(self._create_icon(Icons.STAR))
        else:
            self.bookmark_manager.add_bookmark(title, url)
            self.fav_btn.setIcon(self._create_icon(Icons.STAR_FILLED))
        self.bookmarks_bar.populate()
        
    def new_tab(self):
        # A propria aba nova se gerencia pelo tab_widget
        self.tab_widget.add_new_tab("about:home", self.is_private)
        self.navigate_home()

    def close_current_tab(self):
        index = self.tab_widget.currentIndex()
        if index != -1:
            self.tab_widget.close_tab(index)
            if self.tab_widget.count() == 0:
                self.new_tab()

    def open_private_window(self):
        self.private_window = MainWindow(is_private=True, history_mgr=self.history_manager, bookmark_mgr=self.bookmark_manager, cache_mgr=self.cache_manager)
        self.private_window.show()

    def show_history(self):
        dlg = HistoryDialog(self.history_manager, self)
        dlg.exec()

    def show_bookmarks(self):
        dlg = BookmarksDialog(self.bookmark_manager, self)
        dlg.exec()
        self.bookmarks_bar.populate()

    def toggle_devtools(self):
        if self.dom_viewer.isVisible(): self.dom_viewer.hide()
        else: self.dom_viewer.show()

    def show_fingerprint_panel(self):
        dlg = FingerprintPanel(self.farbling_engine, self)
        dlg.exec()

    def show_extensions(self):
        self.url_bar.setText("about:extensions")
        self.navigate_to_url()
        
    def install_extension_unpacked(self):
        folder = QFileDialog.getExistingDirectory(self, "Selecionar diretório da extensão")
        if folder:
            try:
                from pathlib import Path
                self.extension_manager.install_from_folder(Path(folder))
                self.show_extensions()
            except Exception as e:
                QMessageBox.critical(self, "Erro", str(e))
                
    def install_extension_crx(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Selecionar .crx ou .zip", "", "Extensões (*.crx *.zip)")
        if file_path:
            try:
                from pathlib import Path
                self.extension_manager.install_from_crx(Path(file_path))
                self.show_extensions()
            except Exception as e:
                QMessageBox.critical(self, "Erro", str(e))

    def navigate_home(self):
        self.url_bar.setText("about:home")
        self.navigate_to_url()
        
    def navigate_to_url(self):
        url_text = self.url_bar.text().strip()
        if not url_text: return
        tab = self.tab_widget.get_current_tab()
        
        if url_text == "about:home":
            tab.load_html(self.home_html, url_text, "Redux Browser")
            return
            
        if url_text == "about:extensions":
            ext_html = self.ext_page_gen.generate_html(self.current_theme)
            tab.load_html(ext_html, url_text, "Extensões")
            self._setup_extension_channel(tab)
            return
            
        if url_text == "about:error":
            tab.load_html(self.error_html, url_text, "Erro de Conexão")
            return
            
        if "://" not in url_text:
            url_text = "https://" + url_text
            self.url_bar.setText(url_text)
            
        self._load_network_url(url_text)

    def _load_network_url(self, url: str):
        tab = self.tab_widget.get_current_tab()
        if not tab: return
        
        self.url_bar.setText(url)
        self.history_manager.add_entry(tab.id, url, url, self.is_private)
        
        # update favicon logic will go to tab event
        if self.bookmark_manager.is_bookmarked(url):
            self.fav_btn.setIcon(self._create_icon(Icons.STAR_FILLED))
        else:
            self.fav_btn.setIcon(self._create_icon(Icons.STAR))
            
        tab.load_url(url)
        self.show_floating_status(f"Carregando {url}...")

    def update_url_bar(self, qurl_str):
        if qurl_str == "about:blank": return
        self.url_bar.setText(qurl_str)
        self.url_bar.setCursorPosition(0)
        
        if self.bookmark_manager.is_bookmarked(qurl_str):
            self.fav_btn.setIcon(self._create_icon(Icons.STAR_FILLED))
        else:
            self.fav_btn.setIcon(self._create_icon(Icons.STAR))
        
    def update_title(self, title):
        private_str = " (Privado 🔒)" if self.is_private else ""
        self.setWindowTitle(f"{title} - Redux Browser{private_str}")
        self.show_floating_status(None) # Ocultar ao terminar
            
    def navigate_back(self):
        tab = self.tab_widget.get_current_tab()
        if tab:
            if tab.active_engine == 0:
                tab.back()
            else:
                url = self.history_manager.go_back(tab.id)
                if url: self._load_network_url(url)
        
    def navigate_forward(self):
        tab = self.tab_widget.get_current_tab()
        if tab:
             if tab.active_engine == 0:
                 tab.forward()
             else:
                 url = self.history_manager.go_forward(tab.id)
                 if url: self._load_network_url(url)
        
    def reload_page(self):
        tab = self.tab_widget.get_current_tab()
        if tab: tab.reload()

    def _setup_extension_channel(self, tab):
        if not hasattr(self, 'ext_api_obj'):
            self.ext_api_obj = ReduxExtAPI(self.extension_manager, self)
        
        channel = QWebChannel(tab.web_view.page())
        channel.registerObject("reduxExtAPI", self.ext_api_obj)
        tab.web_view.page().setWebChannel(channel)

class ReduxExtAPI(QObject):
    def __init__(self, ext_manager, main_window):
        super().__init__()
        self.ext_manager = ext_manager
        self.main_window = main_window
        
    @pyqtSlot(str, bool)
    def toggleExtension(self, ext_id, state):
        if state: self.ext_manager.enable(ext_id)
        else: self.ext_manager.disable(ext_id)
        self.main_window.show_extensions()
        
    @pyqtSlot(str)
    def removeExtension(self, ext_id):
        self.ext_manager.uninstall(ext_id)
        self.main_window.show_extensions()
        
    @pyqtSlot()
    def loadUnpacked(self):
        self.main_window.install_extension_unpacked()
        
    @pyqtSlot()
    def installCrx(self):
        self.main_window.install_extension_crx()
