"""
Redux Browser — Renderiza popup de extensão
"""

from PyQt6.QtWidgets import QDialog, QVBoxLayout, QWidget, QGraphicsDropShadowEffect
from PyQt6.QtWebEngineWidgets import QWebEngineView
from PyQt6.QtWebEngineCore import QWebEngineSettings
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QColor
from pathlib import Path

from browser.ui.theme import Theme

class ExtensionPopup(QDialog):
    def __init__(self, extension, extension_manager, parent=None):
        super().__init__(parent)
        self.extension = extension
        self.ext_manager = extension_manager
        self.main_window = parent
        
        current_theme = getattr(parent, 'current_theme', 'dark') if parent else 'dark'
        p = Theme.DARK if current_theme == "dark" else Theme.LIGHT
        
        self.setWindowFlags(Qt.WindowType.Popup | Qt.WindowType.FramelessWindowHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        
        self.setFixedSize(400, 500) # Default popup size limit
        
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(10, 10, 10, 10)
        
        self.container = QWidget(self)
        self.container.setObjectName("popupContainer")
        self.container.setStyleSheet(f"""
            QWidget#popupContainer {{
                background-color: {p['bg_primary']};
                border: 1px solid {p['border']};
                border-radius: 12px;
            }}
        """)
        
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(24)
        shadow.setColor(QColor(0, 0, 0, int(255*0.2 if current_theme == 'light' else 255*0.6)))
        shadow.setOffset(0, 8)
        self.container.setGraphicsEffect(shadow)
        
        main_layout.addWidget(self.container)
        
        self.layout = QVBoxLayout(self.container)
        self.layout.setContentsMargins(0, 0, 0, 0)
        
        self.web_view = QWebEngineView(self)
        # Enable local file access for popups
        self.web_view.settings().setAttribute(QWebEngineSettings.WebAttribute.LocalContentCanAccessRemoteUrls, True)
        self.web_view.settings().setAttribute(QWebEngineSettings.WebAttribute.LocalContentCanAccessFileUrls, True)
        
        self.web_view.setStyleSheet("background: transparent; border: none;")
        self.layout.addWidget(self.web_view)
        
        self._load_popup()
        
    def _load_popup(self):
        if not self.extension.action or not self.extension.action.default_popup:
            return
            
        popup_file = self.extension.action.default_popup
        popup_path = self.extension.path / popup_file
        
        if popup_path.exists():
            # TODO: Inject Chrome APIs shim directly into this QWebEngineView
            # before it executes the popup JS. 
            # We can use QWebEngineScript as we did in content_script_loader
            
            # Using absolute local path for now since we don't have custom scheme handlers set up.
            self.web_view.setUrl(popup_path.absolute().as_uri())
